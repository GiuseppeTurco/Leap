package com.example.leap.data.source.item;

import com.example.leap.data.database.ItemDAO;
import com.example.leap.data.database.ItemDatabase;
import com.example.leap.model.Item;
import com.example.leap.model.ItemResponse;

import java.util.List;

public class ItemLocalDataSource extends BaseItemLocalDataSource{

    private final ItemDAO itemDAO;


    public ItemLocalDataSource(ItemDatabase itemDatabase) {
        this.itemDAO = itemDatabase.itemDAO();

    }

    @Override
    public void getItems() {
        ItemDatabase.databaseWriteExecutor.execute(() -> {
            List<Item> items = itemDAO.getAllItem();
            itemCallback.onSuccessFromLocalItemRetrieve(items);
        });
    }

    @Override
    public void insertItems(List<Item> itemList) {

        ItemDatabase.databaseWriteExecutor.execute(() -> {
            if (itemList != null) {

                // Reads the news from the database
                List<Item> allItems = itemDAO.getAllItem();

                // Checks if the news just downloaded has already been downloaded earlier
                // in order to preserve the news status (marked as favorite or not)
                for (Item items : allItems) {
                    // This check works because News and NewsSource classes have their own
                    // implementation of equals(Object) and hashCode() methods
                    if (itemList.contains(items)) {
                        // The primary key and the favorite status is contained only in the News objects
                        // retrieved from the database, and not in the News objects downloaded from the
                        // Web Service. If the same news was already downloaded earlier, the following
                        // line of code replaces the the News object in newsList with the corresponding
                        // News object saved in the database, so that it has the primary key and the
                        // favorite status.
                        items.setSynchronized(true);
                        itemList.set(itemList.indexOf(items), items);
                    }
                }

                // Writes the news in the database and gets the associated primary keys
                List<Long> insertedNewsIds = itemDAO.insertItemList(itemList);
                for (int i = 0; i < itemList.size(); i++) {
                    // Adds the primary key to the corresponding object News just downloaded so that
                    // if the user marks the news as favorite (and vice-versa), we can use its id
                    // to know which news in the database must be marked as favorite/not favorite
                    itemList.get(i).setId(insertedNewsIds.get(i));
                }

                ItemResponse itemResponse = new ItemResponse();
                itemResponse.setItemList(itemList);
                itemCallback.onSuccessSynchronization();
            }
        });

    }

    @Override
    public void deleteAll() {

    }

    @Override
    public void insertItem(Item item) {
        ItemDatabase.databaseWriteExecutor.execute(() -> {
            itemDAO.addItem(item);
            itemCallback.onSuccessLocalItemInsert(item);

        });

    }
}
