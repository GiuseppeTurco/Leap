package com.example.leap;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class FAQFragment extends Fragment implements View.OnClickListener{

    private final int faqID;
    RecyclerView recyclerView;
    List<Questions> questionsList;

    public FAQFragment(int faqID){
        this.faqID = faqID;
    }
    

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_faq, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recyclerView);
        initData();
        setRecyclerView();
        ImageButton returnButton = view.findViewById(R.id.return_button);
        returnButton.setOnClickListener(this);
    }

    private void setRecyclerView() {
        QuestionsAdapter questionsAdapter = new QuestionsAdapter(questionsList);
        recyclerView.setAdapter(questionsAdapter);
        recyclerView.setHasFixedSize(true);
    }

    @Override
    public void onClick(View v) {
        SettingsFragment settingsFragment = new SettingsFragment();
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fl_wrapper, settingsFragment)
                .commit();
    }

    private void initData() {
        questionsList = new ArrayList<>();
        questionsList.add(new Questions( "Come posso cambiare il tema?", "Puoi cambiare tema cliccando sull'icona delle Impostazioni in basso e attivare/disattivare il tema scuro."));
        questionsList.add(new Questions( "Come posso cambiare lingua?", "Nella sezione delle Impostazioni puoi cambiare facilmente la lingua cliccando sull'ononimo tasto"));
        questionsList.add(new Questions( "Come posso impostare le notifiche per la raccolta differenziata?", "Nelle Impostazioni troverai un'apposita sezione per attivare/disattivare le notifiche per la raccolta differenziata"));
        questionsList.add(new Questions( "Come posso leggere un articolo per intero?", "Dopo aver selezionato l'articolo a cui sei interessato scorri in basso e clicca sul pulsante Leggi tutto"));
        questionsList.add(new Questions( "Come posso cambiare il comune?", "E' possibile cambiare comune cliccando sull'icona del Profilo in alto a destra della Home Page"));

    }
}
