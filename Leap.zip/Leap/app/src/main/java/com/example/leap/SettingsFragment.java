package com.example.leap;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsFragment extends Fragment implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    private Context thiscontext;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        thiscontext = container.getContext();
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView language_textView = view.findViewById(R.id.language_text);
        TextView contact_us_textView = view.findViewById(R.id.contact_us_text);
        TextView about_us_textView = view.findViewById(R.id.about_us_text);
        TextView faq_textView = view.findViewById(R.id.faq_text);

        language_textView.setOnClickListener(this);
        contact_us_textView.setOnClickListener(this);
        about_us_textView.setOnClickListener(this);
        faq_textView.setOnClickListener(this);

        Switch darkModeSwitch = view.findViewById(R.id.darkModeSwitch);
        darkModeSwitch.setOnCheckedChangeListener(this);


        if(MainActivity.preferences.getBoolean("isDark", false)){
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            darkModeSwitch.setChecked(true);
        }else{
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.language_text) {
            Toast.makeText(thiscontext, "che bel pulsante 1", Toast.LENGTH_SHORT).show();
        }else if (v.getId() == R.id.faq_text){
            FAQFragment faqFragment = new FAQFragment(v.getId());
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fl_wrapper, faqFragment)
                    .commit();
        }else if (v.getId() == R.id.about_us_text){
            AboutUsFragment aboutUsFragment = new AboutUsFragment(v.getId());
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fl_wrapper, aboutUsFragment)
                    .commit();
        }else if (v.getId() == R.id.contact_us_text){
            ContactFragment contactFragment = new ContactFragment(v.getId());
            getActivity().getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fl_wrapper, contactFragment)
                    .commit();
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        SharedPreferences.Editor editor = MainActivity.preferences.edit();

        if(isChecked){
            editor.putBoolean("isDark", true);
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        }else{
            editor.putBoolean("isDark", false);
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
        editor.apply();
    }
}