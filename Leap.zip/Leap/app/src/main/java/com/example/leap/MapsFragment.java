package com.example.leap;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapsFragment extends Fragment {

    private SearchView mapSearchView;
    private GoogleMap gmap;
    private Context thiscontext;

    private DatabaseReference reference;

    private OnMapReadyCallback callback = new OnMapReadyCallback() {
        @Override
        public void onMapReady(GoogleMap googleMap) {
            gmap = googleMap;
            LatLng latLng = new LatLng(41.87194, 12.56738);
            gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 5));
            setMarkers();
            gmap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(@NonNull Marker marker) {
                    reference = FirebaseDatabase.getInstance().getReference("Discariche");
                    int index = 0;
                    switch (marker.getTitle()){
                        case "Piattaforma Ecologica di Trezzano":
                            index = 1;
                            break;
                        case "Piattaforma Ecologica di Meda":
                            index = 2;
                            break;
                        case "Piattaforma Ecologica di Monza":
                            index = 3;
                            break;
                    }
                    reference.child(String.valueOf(index)).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                            if(task.isSuccessful() && task.getResult().exists()){
                                DataSnapshot dataSnapshot = task.getResult();
                                String name = String.valueOf(dataSnapshot.child("Nome").getValue());
                                String address = String.valueOf(dataSnapshot.child("Indirizzo").getValue());
                                String monday = String.valueOf(dataSnapshot.child("Lunedì").getValue());
                                String tuesday = String.valueOf(dataSnapshot.child("Martedì").getValue());
                                String wednesday = String.valueOf(dataSnapshot.child("Mercoledì").getValue());
                                String thursday = String.valueOf(dataSnapshot.child("Giovedì").getValue());
                                String friday = String.valueOf(dataSnapshot.child("Venerdì").getValue());
                                String saturday = String.valueOf(dataSnapshot.child("Sabato").getValue());
                                String sunday = String.valueOf(dataSnapshot.child("Domenica").getValue());
                                DumpFragment dumpFragment = new DumpFragment(new Dumps(name, address,monday,tuesday,wednesday,thursday,friday,saturday,sunday));
                                getActivity().getSupportFragmentManager().beginTransaction()
                                        .replace(R.id.fl_wrapper, dumpFragment)
                                        .commit();
                            }
                        }
                    });
                    return false;
                }
            });
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        thiscontext = container.getContext();
        return inflater.inflate(R.layout.fragment_maps, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mapSearchView = view.findViewById(R.id.mapSearch);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);

        mapSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {

                String location = mapSearchView.getQuery().toString();
                List<Address> addressList = null;

                if (location != null) {
                    Geocoder geocoder = new Geocoder(thiscontext, Locale.getDefault());

                    try {
                        addressList = geocoder.getFromLocationName(location, 1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    Address address = addressList.get(0);
                    LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
                    gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
                }

                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        if (mapFragment != null) {
            mapFragment.getMapAsync(callback);
        }
    }

    private void setMarkers(){
        reference = FirebaseDatabase.getInstance().getReference("Discariche");
        for(int i=1;i<=3;i++){
            reference.child(String.valueOf(i)).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if(task.isSuccessful() && task.getResult().exists()){
                        DataSnapshot dataSnapshot = task.getResult();
                        String nome = String.valueOf(dataSnapshot.child("Nome").getValue());
                        float lat = Float.parseFloat(String.valueOf(dataSnapshot.child("Latitudine").getValue()));
                        float lng = Float.parseFloat(String.valueOf(dataSnapshot.child("Longitudine").getValue()));
                        LatLng latLng = new LatLng(lat, lng);
                        MarkerOptions marker = new MarkerOptions();
                        marker.title(nome);
                        marker.position(latLng);
                        marker.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN));
                        gmap.addMarker(marker);
                    }
                }
            });
        }
    }
}