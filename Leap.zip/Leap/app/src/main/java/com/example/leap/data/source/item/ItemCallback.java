package com.example.leap.data.source.item;

import com.example.leap.model.Item;
import com.example.leap.model.ItemResponse;

import java.util.List;

public interface ItemCallback {

    void onSuccessSynchronization();
    void onSuccessDeletion();

    void onSuccessLocalItemInsert(Item item);

    void onSuccessFromRemoteDatabase(Item item);
    void onSuccessFromLocalItemRetrieve(List<Item> itemList);

    void onFailureFromRemoteDatabase(String errorGettingData);
}
