package com.example.leap.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.MenuProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

import com.example.leap.R;
import com.example.leap.adapter.NewsListAdapter;
import com.example.leap.model.News;
import com.example.leap.model.Result;
import com.example.leap.util.Constants;
import com.example.leap.util.ErrorMessagesUtil;
import com.example.leap.util.SharedPreferencesUtil;


public class FavoriteNewsFragment extends Fragment {

    private static final String TAG = FavoriteNewsFragment.class.getSimpleName();

    private List<News> newsList;
    private NewsListAdapter newsListAdapter;
    private ProgressBar progressBar;
    private NewsViewModel newsViewModel;

    public FavoriteNewsFragment() {

    }
    public static FavoriteNewsFragment newInstance() {
        return new FavoriteNewsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        newsList = new ArrayList<>();
        newsViewModel = new ViewModelProvider(requireActivity()).get(NewsViewModel.class);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_favorite_news, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        progressBar = view.findViewById(R.id.progress_bar);

        ImageButton imageButton = view.findViewById(R.id.return_arrow_15);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(view).navigate(R.id.action_favoriteNewsFragment_to_newsFragment);
            }
        });

        ListView listViewFavNews = view.findViewById(R.id.listview_fav_news);

        newsListAdapter =
                new NewsListAdapter(requireContext(), R.layout.favorite_news_list_item, newsList,
                        news -> {
                            news.setFavorite(false);
                            newsViewModel.removeFromFavorite(news);
                        });
        listViewFavNews.setAdapter(newsListAdapter);

        progressBar.setVisibility(View.VISIBLE);

        SharedPreferencesUtil sharedPreferencesUtil =
                new SharedPreferencesUtil(requireActivity().getApplication());

        boolean isFirstLoading = sharedPreferencesUtil.readBooleanData(Constants.SHARED_PREFERENCES_FILE_NAME,
                Constants.SHARED_PREFERENCES_FIRST_LOADING);

        newsViewModel.getFavoriteNewsLiveData(isFirstLoading).observe(getViewLifecycleOwner(), result -> {
            if (result != null) {
                if (result.isSuccess()) {
                    newsList.clear();
                    newsList.addAll(((Result.NewsResponseSuccess)result).getData().getNewsList());
                    newsListAdapter.notifyDataSetChanged();
                    if (isFirstLoading) {
                        sharedPreferencesUtil.writeBooleanData(Constants.SHARED_PREFERENCES_FILE_NAME,
                                Constants.SHARED_PREFERENCES_FIRST_LOADING, false);
                    }
                } else {
                    ErrorMessagesUtil errorMessagesUtil =
                            new ErrorMessagesUtil(requireActivity().getApplication());
                    Snackbar.make(view, errorMessagesUtil.
                                    getErrorMessage(((Result.Error)result).getMessage()),
                            Snackbar.LENGTH_SHORT).show();
                }
                progressBar.setVisibility(View.GONE);
            }
        });

        listViewFavNews.setOnItemClickListener((parent, view1, position, id) -> {
            FavoriteNewsFragmentDirections.ActionFavoriteNewsFragmentToNewsDetailFragment action =
                    FavoriteNewsFragmentDirections.
                            actionFavoriteNewsFragmentToNewsDetailFragment(newsList.get(position));
            Navigation.findNavController(view).navigate(action);
        });
    }
}
