package com.example.leap.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.MenuProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.navigation.NavBackStackEntry;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import com.example.leap.R;
import com.example.leap.databinding.FragmentNewsDetailBinding;
import com.example.leap.model.News;

public class NewsDetailFragment extends Fragment {

    private static final String TAG = NewsDetailFragment.class.getSimpleName();

    private FragmentNewsDetailBinding fragmentNewsDetailBinding;

    public NewsDetailFragment() {
        // Required empty public constructor
    }


    public static NewsDetailFragment newInstance() {
        return new NewsDetailFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentNewsDetailBinding = FragmentNewsDetailBinding.inflate(inflater, container, false);
        return fragmentNewsDetailBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        requireActivity().addMenuProvider(new MenuProvider() {
            @Override
            public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
                menu.clear();
            }

            @Override
            public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
                if (menuItem.getItemId() == android.R.id.home) {
                    Navigation.findNavController(requireView()).navigateUp();
                }
                return false;
            }
        }, getViewLifecycleOwner(), Lifecycle.State.RESUMED);

        News news = NewsDetailFragmentArgs.fromBundle(getArguments()).getNews();

        Glide.with(fragmentNewsDetailBinding.idIVNews.getContext()).
                load(news.getUrlToImage()).
                placeholder(R.drawable.ic_baseline_cloud_download_24).
                into(fragmentNewsDetailBinding.idIVNews);

        fragmentNewsDetailBinding.idTVTitle.setText(news.getTitle());
        fragmentNewsDetailBinding.idTVContent.setText(news.getContent());

        fragmentNewsDetailBinding.returnArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_newsDetailFragment_to_newsFragment);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        fragmentNewsDetailBinding = null;
    }
}
