package com.example.leap.data.repository.user;

import androidx.lifecycle.MutableLiveData;

import java.util.Set;

import com.example.leap.model.Result;
import com.example.leap.model.User;

public interface IUserRepository {
    MutableLiveData<Result> getUser(String name, String surname, String email, String password, String comune, boolean isUserRegistered);
    MutableLiveData<Result> getUser(String idToken);
    MutableLiveData<Result> getGoogleUser(String idToken);
    MutableLiveData<Result> logout();
    User getLoggedUser();
    User retriveUserData(String idToken);
    void signUp(String name, String surname, String email, String password, String comune);
    void signIn(String email, String password);
    void signInWithGoogle(String token);
}
