package com.example.leap.ui.main;

import android.app.Application;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.leap.data.database.ItemDatabase;
import com.example.leap.data.repository.item.IItemRepository;
import com.example.leap.data.repository.item.ItemRepository;
import com.example.leap.data.source.item.BaseItemDataRemoteDataSource;
import com.example.leap.data.source.item.ItemDataRemoteDataSource;
import com.example.leap.data.source.item.ItemLocalDataSource;
import com.example.leap.model.Item;
import com.example.leap.model.Result;
import com.example.leap.ui.welcome.UserViewModel;

public class BarcodeViewModel extends ViewModel {
    private static final String TAG = UserViewModel.class.getSimpleName();

    private final IItemRepository itemRepository;
    private MutableLiveData<Result> itemMutableLiveData;
    private BaseItemDataRemoteDataSource baseItemDataRemoteDataSource;
    private ItemLocalDataSource itemLocalDataSource;
    private boolean isLoading;
    private boolean firstLoading;

    public BarcodeViewModel(IItemRepository itemRepository, Application application) {
        this.baseItemDataRemoteDataSource = new ItemDataRemoteDataSource();
        this.itemLocalDataSource = new ItemLocalDataSource(ItemDatabase.getDatabase(application));
        this.itemRepository = new ItemRepository(baseItemDataRemoteDataSource, itemLocalDataSource);
    }

    public MutableLiveData<Result> getItemMutableLiveData(Long ean) {
        getItemData(ean);
        return itemMutableLiveData;
    }
    public MutableLiveData<Result> insertItem(Item item){

        itemMutableLiveData = itemRepository.insertItem(item);
        return  itemMutableLiveData;


    }
    public MutableLiveData<Result> getItemsMutableLiveData() {
        getItemsData();
        return itemMutableLiveData;

    }
    private void getItemsData() {
        itemMutableLiveData = itemRepository.getItems();
    }

    private void getItemData(Long ean) {
        itemMutableLiveData = itemRepository.getItem(ean);
    }

    public void setFirstLoading(boolean firstLoading) {
        this.firstLoading = firstLoading;
    }
    public void setLoading(boolean loading) {
        isLoading = loading;
    }
}