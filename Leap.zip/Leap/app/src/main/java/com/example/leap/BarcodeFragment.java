package com.example.leap;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class BarcodeFragment extends Fragment {

    ImageButton scanButton;
    Context thiscontext;
    RecyclerView lv_item_list;
    SwipeRefreshLayout swipeRefreshLayout;
    View view;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    boolean bool = true;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        assert container != null;
        thiscontext = container.getContext();

        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_barcode, container, false);

        // Get the button view from the layout
        scanButton = view.findViewById(R.id.bScan);


        //get the listview view from the layout
        lv_item_list = view.findViewById(R.id.lv_item_list);

        // Set up the click listener for the scan button
        scanButton.setOnClickListener(v-> startActivity(new Intent(thiscontext, BarcodeActivity.class)));

        updateReyclerView(view);

        // Initialize the SwipeRefreshLayout object

        swipeRefreshLayout = getView().findViewById(R.id.swipeRefreshLayout);


        // Check if the SwipeRefreshLayout object is not null
        if (swipeRefreshLayout != null) {
            // Set the OnRefreshListener

            swipeRefreshLayout.setOnRefreshListener(() -> {
                // Do something when the swipe refresh layout is refreshed
                updateReyclerView(view);
                swipeRefreshLayout.setRefreshing(false);
            });
        } else {
            // Handle the case where the swipe refresh layout is null
            Toast.makeText(thiscontext, "error while loading the swiperefresher", Toast.LENGTH_SHORT);
        }

        //updateReyclerView(view);


        return view;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



    }

    public void updateReyclerView(View view ){
        //recycle view displayer
        DataBaseHelper dataBaseHelper = new DataBaseHelper(thiscontext);
        List<Item> everything = new ArrayList<>();
        everything.add(new Item());
        everything = dataBaseHelper.getAll();
        //recycler view part
        recyclerView = view.findViewById(R.id.lv_item_list);

        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(thiscontext);
        recyclerView.setLayoutManager(layoutManager);

        mAdapter = new RecyclerViewAdapter(everything, thiscontext);
        recyclerView.setAdapter(mAdapter);
    }

    @Nullable
    @Override
    public View getView() {
        return view;
    }
}