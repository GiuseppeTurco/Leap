package com.example.leap;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.List;

public class BarcodeFragment extends Fragment {

    Button scanButton, viewAllButton;
    Context thiscontext;
    RecyclerView lv_item_list;

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        assert container != null;
        thiscontext = container.getContext();
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_barcode, container, false);

        // Get the button view from the layout
        scanButton = view.findViewById(R.id.bScan);
        viewAllButton = view.findViewById(R.id.bViewAll);


                //get the listview view from the layout
        lv_item_list = view.findViewById(R.id.lv_item_list);

        // Set up the click listener for the scan button
        scanButton.setOnClickListener(v-> startActivity(new Intent(thiscontext, BarcodeActivity.class)));


        //recycle view displayer
        DataBaseHelper dataBaseHelper = new DataBaseHelper(thiscontext);
        List<Item> everything = dataBaseHelper.getAll();
        //recycler view part
        recyclerView = view.findViewById(R.id.lv_item_list);

        recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(thiscontext);
        recyclerView.setLayoutManager(layoutManager);

        mAdapter = new RecyclerViewAdapter(everything, thiscontext);
        recyclerView.setAdapter(mAdapter);

        //Set up click listener for the view all button

        viewAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataBaseHelper dataBaseHelper = new DataBaseHelper(thiscontext);
                List<Item> everything = dataBaseHelper.getAll();
                //recycler view part
                recyclerView = view.findViewById(R.id.lv_item_list);

                recyclerView.setHasFixedSize(true);
                layoutManager = new LinearLayoutManager(thiscontext);
                recyclerView.setLayoutManager(layoutManager);

                mAdapter = new RecyclerViewAdapter(everything, thiscontext);
                recyclerView.setAdapter(mAdapter);


            }
        });


        return view;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }
}
