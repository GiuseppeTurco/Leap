package com.example.leap.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.leap.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AboutUsFragment extends Fragment implements View.OnClickListener{

    RecyclerView recyclerView;
    List<Questions> infoList;

    public AboutUsFragment(){}


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_about_us, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.recyclerViewAboutUs);

        initData();
        setRecyclerView();
        ImageButton returnButton = view.findViewById(R.id.return_arrow_5);
        returnButton.setOnClickListener(this);
    }


    private void setRecyclerView() {
        QuestionsAdapter questionsAdapter = new QuestionsAdapter(infoList);
        recyclerView.setAdapter(questionsAdapter);
        recyclerView.setHasFixedSize(true);
    }

    @Override
    public void onClick(View v) {
        Navigation.findNavController(v).navigate(R.id.action_aboutUsFragment_to_settingsFragment);
    }

    private void initData() {
        infoList = new ArrayList<>();

        if(Locale.getDefault().getLanguage().equals("it")){
            infoList.add(new Questions( "Chi siamo", "Leap è un progetto volto al miglioramento delle nostre abitudini per quanto concerne la raccolta differenziata. " +
                    "un sistema di gestione dei rifiuti che prevede la separazione e la raccolta di materiali diversi al momento del loro smaltimento. Questo processo serve a diversi scopi importanti:" +
                    "\n1) Riduzione dell'inquinamento ambientale: La separazione dei rifiuti consente di ridurre l'inquinamento ambientale, poiché alcuni materiali possono essere riciclati o riutilizzati invece di essere smaltiti in discarica o inceneriti. " +
                    "\n2) Conservazione delle risorse: La raccolta differenziata facilita il riciclo di materiali come carta, plastica, vetro e metalli. Riciclare questi materiali permette di risparmiare energia e materie prime, contribuendo a preservare le risorse naturali e a ridurre l'impatto ambientale associato all'estrazione e alla produzione di nuovi materiali." +
                    "\n3) Riduzione dei costi di smaltimento: Separare i rifiuti in modo corretto può ridurre i costi associati allo smaltimento dei rifiuti. Il riciclo e il riutilizzo dei materiali consentono di ridurre la quantità di rifiuti che devono essere smaltiti in discarica o inceneriti, riducendo quindi i costi per la gestione dei rifiuti." +
                    "\n4) Promozione di un comportamento sostenibile: La raccolta differenziata promuove un comportamento più consapevole e sostenibile tra i cittadini." +
                    ""));
            infoList.add(new Questions( "La nostra missione", "Spesso si è indecisi sul come iniziare a fare la raccolta differenziata in modo corretto: Leap si impegna a darti un supporto valido e concreto nel tuo viaggio verso pratiche più sostenibili"));
            infoList.add(new Questions( "Team di sviluppo", "Leap è il frutto del lavoro di tre giovani aspiranti programmatori, studenti dell'Università di Milano Bicocca. L'idea sarebbe quella di implementare un'applicazione utile a migliorare la qualità dell'ambiente che ci circonda, dato che le tematiche dell'inquinamento riguardano da vicino soprattutto le nuove generazioni"));
            infoList.add(new Questions( "Aggiornamenti futuri", "Ci prefiggiamo in futuro di riuscire ad ampliare le funzionalità dell'applicazione, in modo da stimolarne l'uso e renderla sempre più semplice e facile nell'utilizzo."));
        }else{
            infoList.add(new Questions( "Who we are", "Leap is a project aimed at improving our habits regarding waste sorting. " +
                    "A waste management system that involves the separation and collection of different materials at the time of their disposal. This process serves various important purposes:" +
                    "\n1) Reduction of environmental pollution: Waste separation helps reduce environmental pollution, as some materials can be recycled or reused instead of being disposed of in landfills or incinerated. " +
                    "\n2) Conservation of resources: Waste separation facilitates the recycling of materials such as paper, plastic, glass, and metals. Recycling these materials helps save energy and raw materials, contributing to the preservation of natural resources and reducing the environmental impact associated with the extraction and production of new materials." +
                    "\n3) Waste disposal cost reduction: Proper waste separation can reduce the costs associated with waste disposal. Recycling and reusing materials help reduce the amount of waste that needs to be disposed of in landfills or incinerated, thus lowering waste management costs." +
                    "\n4) Promotion of sustainable behavior: Waste separation promotes a more conscious and sustainable behavior among citizens." +
                    ""));
            infoList.add(new Questions( "Our mission", "Often, one is undecided about how to start doing recycling correctly. Leap is committed to providing you with valid and concrete support on your journey towards more sustainable practices."));
            infoList.add(new Questions( "Development Team", "Leap is the result of the work of three young aspiring programmers, students at the University of Milano Bicocca. The idea is to implement an application aimed at improving the quality of the environment around us, as pollution issues closely affect the younger generations."));
            infoList.add(new Questions( "Future updates", "In the future, we aim to expand the functionality of the application, encouraging its use and making it increasingly simple and user-friendly."));
        }
    }
}
