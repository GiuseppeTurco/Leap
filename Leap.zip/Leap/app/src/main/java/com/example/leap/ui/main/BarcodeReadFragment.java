package com.example.leap.ui.main;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.example.leap.R;
import com.example.leap.data.database.ItemDatabase;
import com.example.leap.data.repository.item.ItemRepository;
import com.example.leap.data.source.item.BaseItemDataRemoteDataSource;
import com.example.leap.data.source.item.ItemDataRemoteDataSource;
import com.example.leap.data.source.item.ItemLocalDataSource;
import com.example.leap.model.Item;
import com.example.leap.model.Result;
import com.google.android.material.snackbar.Snackbar;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class BarcodeReadFragment extends Fragment {

    Button tryagain, bConfirm;
    ImageButton exit;
    Long ean;
    BarcodeViewModel barcodeViewModel;
    private ItemLocalDataSource itemLocalDataSource;
    private BaseItemDataRemoteDataSource baseItemDataRemoteDataSource;
    private ItemRepository itemRepository;


    private Item item;

    public BarcodeReadFragment() {
        // Required empty public constructor
    }

    public BarcodeReadFragment( Item item) {
        this.item = item;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        itemLocalDataSource = new ItemLocalDataSource(ItemDatabase.getDatabase(getContext()));
        baseItemDataRemoteDataSource = new ItemDataRemoteDataSource();
        itemRepository = new ItemRepository(baseItemDataRemoteDataSource, itemLocalDataSource);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_barcode_read, container, false);

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tryagain = getActivity().findViewById(R.id.btn_scan);
        exit = getActivity().findViewById(R.id.return_arrow_3);
        bConfirm = getActivity().findViewById(R.id.bConfirm);
        barcodeViewModel = new ViewModelProvider(
                this,
                new BarcodeViewModelFactory(itemRepository, requireActivity().getApplication())).get(BarcodeViewModel.class);

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();

            }
        });

        bConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                barcodeViewModel.insertItem(item).observe(getViewLifecycleOwner(),result -> {
                    if(result.isSuccess()){
                        closeFragment();
                    }
                    else{
                        Log.w("TAG", "onClick: fallito " );
                    }
                });
            }
        });

        scanCode();

        tryagain.setOnClickListener(v-> scanCode());


    }

    private void scanCode() {

        ScanOptions options = new ScanOptions();
        options.setOrientationLocked(true);
        options.setCaptureActivity(CaptureAct.class);
        barcodeLauncher.launch(options);
    }
    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
            result -> {
                if(result.getContents() == null) {
                } else {
                    TextView textView = getActivity().findViewById(R.id.tvEANres);
                    textView.setText(result.getContents());
                    dati();
                }
            });

    void closeFragment(){
        Navigation.findNavController(getView()).navigate(R.id.action_barcodeReadFragment_to_barcodeFragment);
    }

    public void dati() {

        TextView textView = getActivity().findViewById(R.id.tvEANres);
        ean = Long.valueOf(textView.getText().toString());
        if(!(ean == 0)){
            getItem(ean);
        }
        else {

        }
    }

    private void readData(Item item) {
        TextView resBrand = getActivity().findViewById(R.id.tvBrand);
        TextView resName = getActivity().findViewById(R.id.tvItem);
        TextView resPackaging = getActivity().findViewById(R.id.tvPackging);

        resBrand.setText(item.getBrand());
        resName.setText(item.getProdName());
        resPackaging.setText(item.getPackaging());

    }
    private void getItem(Long ean){
        barcodeViewModel.getItemMutableLiveData(ean).observe(
                getViewLifecycleOwner(), result -> {
                    if (result.isSuccess()) {
                        item = ((Result.ItemResponseSuccess) result).getData();
                        Snackbar.make(getActivity().findViewById(android.R.id.content),
                                item.getProdName(), Snackbar.LENGTH_SHORT).show();
                        readData(item);

                    } else {
                        Snackbar.make(getActivity().findViewById(android.R.id.content),
                                "Error", Snackbar.LENGTH_SHORT).show();
                    }
                });
    }


}