package com.example.leap.data.repository.dump;

import androidx.lifecycle.MutableLiveData;

import com.example.leap.model.Dump;
import com.example.leap.model.Result;
import com.example.leap.model.User;

import java.util.List;

public interface IDumpRepository {
    MutableLiveData<Result> getDump();
    void retriveDumpData();
}
