package com.example.leap;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;


public class BarcodeActivity extends AppCompatActivity {

    Button tryagain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barcode);
        tryagain = findViewById(R.id.btn_scan);
        tryagain.setOnClickListener(v->{
            scanCode();
        });
        scanCode();


    }

    private void scanCode() {
        ScanOptions options = new ScanOptions();
        options.setOrientationLocked(true);
        options.setCaptureActivity(CaptureAct.class);
        barcodeLauncher.launch(options);
    }
    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
            result -> {
                if(result.getContents() == null) {
                    Toast.makeText(BarcodeActivity.this, "Cancelled", Toast.LENGTH_LONG).show();
                } else {
                    setContentView(R.layout.activity_barcode);
                    TextView textView = findViewById(R.id.resultView);
                    textView.setText(getString(R.string.scan_res)+ ": " + result.getContents());
                }
            });

}