package com.example.leap;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;


public class BarcodeActivity extends AppCompatActivity {

    Button tryagain, exit;
    String brand, packaging, prodName, ean;

    Item item;

    DatabaseReference reference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barcode);
        tryagain = findViewById(R.id.btn_scan);
        exit = findViewById(R.id.bExit);



        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{

                    item = new Item(ean, prodName, brand, packaging);
                    toastie(item.toString());
                }
                catch (Exception e ) {
                    toastie("nuh huh");
                    item = new Item("-1", "error", "error", "error");
                }
                DataBaseHelper dataBaseHelper = new DataBaseHelper(BarcodeActivity.this);
                boolean success = dataBaseHelper.addOne(item);

                toastie(String.valueOf(success));

                finish();
            }
        });

        scanCode();

        tryagain.setOnClickListener(v-> scanCode());

    }


    private void scanCode() {

        ScanOptions options = new ScanOptions();
        options.setOrientationLocked(true);
        options.setCaptureActivity(CaptureAct.class);
        barcodeLauncher.launch(options);
    }
    private final ActivityResultLauncher<ScanOptions> barcodeLauncher = registerForActivityResult(new ScanContract(),
            result -> {
                if(result.getContents() == null) {
                    Toast.makeText(BarcodeActivity.this, "Cancelled", Toast.LENGTH_LONG).show();

                } else {
                    TextView textView = findViewById(R.id.tvISBNres);
                    textView.setText(result.getContents());

                    data();
                }
            });

    public void toastie(String str){
        Toast.makeText(BarcodeActivity.this, str, Toast.LENGTH_SHORT).show();
    }


    public void data() {

        TextView textView = findViewById(R.id.tvISBNres);
        ean = textView.getText().toString();
        if(!ean.isEmpty()){
            readData(ean);
        }
        else {
            toastie("please enter a isbn");
        }
    }

    private void readData(String ISBNres) {

        reference = FirebaseDatabase.getInstance().getReference("Products");
        reference.child(ISBNres).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {

                if(task.isSuccessful()){
                    if(task.getResult().exists()){
                        toastie("success");
                        DataSnapshot dataSnapshot = task.getResult();
                        brand = (String) dataSnapshot.child("Brand").getValue();
                        prodName = (String) dataSnapshot.child("Name").getValue();
                        packaging = (String) dataSnapshot.child("Packaging").getValue();
                        TextView tvBrand = findViewById(R.id.tvBrand);
                        tvBrand.setText(brand);
                        TextView tvProduct = findViewById(R.id.tvItem);
                        tvProduct.setText(prodName);
                        TextView tvPackaging = findViewById(R.id.tvPackging);
                        tvPackaging.setText(packaging);





                    }else{
                        toastie("isbn doesn't exist");
                    }

                }else{
                    toastie("failed to read");
                }

            }
        });
    }


}