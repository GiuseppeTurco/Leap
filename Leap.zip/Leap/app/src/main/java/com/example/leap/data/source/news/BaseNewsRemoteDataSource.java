package com.example.leap.data.source.news;

public abstract class BaseNewsRemoteDataSource {
    protected NewsCallback newsCallback;

    public void setNewsCallback(NewsCallback newsCallback) {
        this.newsCallback = newsCallback;
    }

    public abstract void getNews(String country, int page);
}
