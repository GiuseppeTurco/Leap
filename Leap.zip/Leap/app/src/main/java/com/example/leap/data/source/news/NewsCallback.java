package com.example.leap.data.source.news;

import java.util.List;

import com.example.leap.model.News;
import com.example.leap.model.NewsApiResponse;


public interface NewsCallback {
    void onSuccessFromRemote(NewsApiResponse newsApiResponse, long lastUpdate);
    void onFailureFromRemote(Exception exception);
    void onSuccessFromLocal(NewsApiResponse newsApiResponse);
    void onFailureFromLocal(Exception exception);
    void onNewsFavoriteStatusChanged(News news, List<News> favoriteNews);
    void onNewsFavoriteStatusChanged(List<News> news);
    void onDeleteFavoriteNewsSuccess(List<News> favoriteNews);
    void onSuccessFromCloudReading(List<News> newsList);
    void onSuccessFromCloudWriting(News news);
    void onFailureFromCloud(Exception exception);
    void onSuccessSynchronization();
    void onSuccessDeletion();
}
