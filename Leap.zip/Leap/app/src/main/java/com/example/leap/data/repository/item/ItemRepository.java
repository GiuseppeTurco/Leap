package com.example.leap.data.repository.item;

import androidx.lifecycle.MutableLiveData;

import com.example.leap.data.source.item.BaseItemDataRemoteDataSource;
import com.example.leap.data.source.item.BaseItemLocalDataSource;
import com.example.leap.data.source.item.ItemCallback;
import com.example.leap.data.source.item.ItemLocalDataSource;
import com.example.leap.model.Item;
import com.example.leap.model.Result;

import java.util.List;

public class ItemRepository implements IItemRepository, ItemCallback {
    private static final String TAG = ItemRepository.class.getSimpleName();
    private final BaseItemDataRemoteDataSource baseItemDataRemoteDataSource;
    private final MutableLiveData<Result> itemMutableLiveData;
    private final BaseItemLocalDataSource baseItemLocalDataSource;

    public ItemRepository(BaseItemDataRemoteDataSource baseItemDataRemoteDataSource, ItemLocalDataSource baseItemLocalDataSource) {
        this.baseItemDataRemoteDataSource = baseItemDataRemoteDataSource;
        this.baseItemLocalDataSource = baseItemLocalDataSource;
        this.itemMutableLiveData = new MutableLiveData<>();
        this.baseItemDataRemoteDataSource.setItemResponseCallback(this);
        this.baseItemLocalDataSource.setItemCallback(this);
    }



    @Override
    public MutableLiveData<Result> getItem(Long ean) {
        retrieveItemData(ean);
        return itemMutableLiveData;
    }

    public MutableLiveData<Result> getItems(){
        retrieveItemsData();
        return itemMutableLiveData;
    }


    public void onSuccessFromRemoteDatabase(List<Item> itemList) {
        baseItemLocalDataSource.insertItems(itemList);
    }

    public void retrieveItemsData(){
        baseItemLocalDataSource.getItems();
    }

    @Override
    public void retrieveItemData(Long ean) {
        baseItemDataRemoteDataSource.getItem(ean);
    }

    public MutableLiveData<Result> insertItem(Item item){
        baseItemLocalDataSource.insertItem(item);

        return itemMutableLiveData;
    }



    @Override
    public void onSuccessSynchronization() {

    }

    @Override
    public void onSuccessDeletion() {

    }

    @Override
    public void onSuccessLocalItemInsert(Item item) {
        Result result = new Result.ItemResponseSuccess(item);
        itemMutableLiveData.postValue(result);
    }

    @Override
    public void onSuccessFromRemoteDatabase(Item item) {
        Result.ItemResponseSuccess result = new Result.ItemResponseSuccess(item);
        itemMutableLiveData.postValue(result);

    }

    @Override
    public void onSuccessFromLocalItemRetrieve(List<Item> itemList) {
        Result.ItemResponseSuccess result = new Result.ItemResponseSuccess(itemList);
        itemMutableLiveData.postValue(result);
    }

    @Override
    public void onFailureFromRemoteDatabase(String errorGettingData) {
        Result.Error result = new Result.Error(errorGettingData);
        itemMutableLiveData.postValue(result);
    }
}