package com.example.leap.data.source.news;

import static com.example.leap.util.Constants.ENCRYPTED_DATA_FILE_NAME;
import static com.example.leap.util.Constants.ENCRYPTED_SHARED_PREFERENCES_FILE_NAME;
import static com.example.leap.util.Constants.LAST_UPDATE;
import static com.example.leap.util.Constants.SHARED_PREFERENCES_FILE_NAME;
import static com.example.leap.util.Constants.UNEXPECTED_ERROR;

import java.util.List;

import com.example.leap.data.database.NewsDao;
import com.example.leap.data.database.NewsRoomDatabase;
import com.example.leap.model.News;
import com.example.leap.model.NewsApiResponse;
import com.example.leap.util.DataEncryptionUtil;
import com.example.leap.util.SharedPreferencesUtil;

public class NewsLocalDataSource extends BaseNewsLocalDataSource {

    private final NewsDao newsDao;
    private final SharedPreferencesUtil sharedPreferencesUtil;
    private final DataEncryptionUtil dataEncryptionUtil;

    public NewsLocalDataSource(NewsRoomDatabase newsRoomDatabase,
                               SharedPreferencesUtil sharedPreferencesUtil,
                               DataEncryptionUtil dataEncryptionUtil
                               ) {
        this.newsDao = newsRoomDatabase.newsDao();
        this.sharedPreferencesUtil = sharedPreferencesUtil;
        this.dataEncryptionUtil = dataEncryptionUtil;
    }

    @Override
    public void getNews() {
        NewsRoomDatabase.databaseWriteExecutor.execute(() -> {
            //TODO Fix this instruction
            NewsApiResponse newsApiResponse = new NewsApiResponse();
            newsApiResponse.setNewsList(newsDao.getAll());
            newsCallback.onSuccessFromLocal(newsApiResponse);
        });
    }

    @Override
    public void getFavoriteNews() {
        NewsRoomDatabase.databaseWriteExecutor.execute(() -> {
            List<News> favoriteNews = newsDao.getFavoriteNews();
            newsCallback.onNewsFavoriteStatusChanged(favoriteNews);
        });
    }

    @Override
    public void updateNews(News news) {
        NewsRoomDatabase.databaseWriteExecutor.execute(() -> {
            if (news != null) {
                int rowUpdatedCounter = newsDao.updateSingleFavoriteNews(news);
                if (rowUpdatedCounter == 1) {
                    News updatedNews = newsDao.getNews(news.getId());
                    newsCallback.onNewsFavoriteStatusChanged(updatedNews, newsDao.getFavoriteNews());
                } else {
                    newsCallback.onFailureFromLocal(new Exception(UNEXPECTED_ERROR));
                }
            } else {
                List<News> allNews = newsDao.getAll();
                for (News n : allNews) {
                    n.setSynchronized(false);
                    newsDao.updateSingleFavoriteNews(n);
                }
            }
        });
    }

    @Override
    public void deleteFavoriteNews() {
        NewsRoomDatabase.databaseWriteExecutor.execute(() -> {
            List<News> favoriteNews = newsDao.getFavoriteNews();
            for (News news : favoriteNews) {
                news.setFavorite(false);
            }
            int updatedRowsNumber = newsDao.updateListFavoriteNews(favoriteNews);

            if (updatedRowsNumber == favoriteNews.size()) {
                newsCallback.onDeleteFavoriteNewsSuccess(favoriteNews);
            } else {
                newsCallback.onFailureFromLocal(new Exception(UNEXPECTED_ERROR));
            }
        });
    }

    @Override
    public void insertNews(NewsApiResponse newsApiResponse) {
        NewsRoomDatabase.databaseWriteExecutor.execute(() -> {

            List<News> allNews = newsDao.getAll();
            List<News> newsList = newsApiResponse.getNewsList();

            if (newsList != null) {
                for (News news : allNews) {
                    if (newsList.contains(news)) {
                        newsList.set(newsList.indexOf(news), news);
                    }
                }

                List<Long> insertedNewsIds = newsDao.insertNewsList(newsList);
                for (int i = 0; i < newsList.size(); i++) {
                    newsList.get(i).setId(insertedNewsIds.get(i));
                }

                sharedPreferencesUtil.writeStringData(SHARED_PREFERENCES_FILE_NAME,
                        LAST_UPDATE, String.valueOf(System.currentTimeMillis()));

                newsCallback.onSuccessFromLocal(newsApiResponse);
            }
        });
    }

    @Override
    public void insertNews(List<News> newsList) {
        NewsRoomDatabase.databaseWriteExecutor.execute(() -> {
            if (newsList != null) {
                List<News> allNews = newsDao.getAll();
                for (News news : allNews) {
                    if (newsList.contains(news)) {
                        news.setSynchronized(true);
                        newsList.set(newsList.indexOf(news), news);
                    }
                }

                List<Long> insertedNewsIds = newsDao.insertNewsList(newsList);
                for (int i = 0; i < newsList.size(); i++) {
                    newsList.get(i).setId(insertedNewsIds.get(i));
                }

                NewsApiResponse newsApiResponse = new NewsApiResponse();
                newsApiResponse.setNewsList(newsList);
                newsCallback.onSuccessSynchronization();
            }
        });
    }

    @Override
    public void deleteAll() {
        NewsRoomDatabase.databaseWriteExecutor.execute(() -> {
            int newsCounter = newsDao.getAll().size();
            int newsDeletedNews = newsDao.deleteAll();

            if (newsCounter == newsDeletedNews) {
                sharedPreferencesUtil.deleteAll(SHARED_PREFERENCES_FILE_NAME);
                dataEncryptionUtil.deleteAll(ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, ENCRYPTED_DATA_FILE_NAME);
                newsCallback.onSuccessDeletion();
            }
        });
    }
}
