package com.example.leap.data.source.dump;

import static com.example.leap.util.Constants.COMUNE;
import static com.example.leap.util.Constants.EMAIL_ADDRESS;
import static com.example.leap.util.Constants.FIREBASE_DUMPS_COLLECTION;
import static com.example.leap.util.Constants.FIREBASE_REALTIME_DATABASE;
import static com.example.leap.util.Constants.FIREBASE_USERS_COLLECTION;
import static com.example.leap.util.Constants.NAME;
import static com.example.leap.util.Constants.SURNAME;

import android.util.Log;

import androidx.annotation.NonNull;

import com.example.leap.data.source.user.UserDataRemoteDataSource;
import com.example.leap.model.Dump;
import com.example.leap.model.User;
import com.example.leap.util.SharedPreferencesUtil;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class DumpDataRemoteDataSource extends BaseDumpDataRemoteDataSource{

    private static final String TAG = DumpDataRemoteDataSource.class.getSimpleName();

    private final DatabaseReference databaseReference;

    public DumpDataRemoteDataSource() {
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance(FIREBASE_REALTIME_DATABASE);
        databaseReference = firebaseDatabase.getReference().getRef();
    }

    @Override
    public ArrayList<Dump> getDump() {
        databaseReference.child(FIREBASE_DUMPS_COLLECTION).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e(TAG, "Error getting data");
                    dumpResponseCallback.onFailureFromRemoteDatabase("Error getting data");
                }
                else {
                    DataSnapshot dataSnapshot = task.getResult();
                    ArrayList<Dump> dumpArrayList = new ArrayList<>();
                    for(int i=1;i<4;i++){
                        String name = String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Nome").getValue());
                        String address = String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Indirizzo").getValue());
                        float lat = Float.parseFloat(String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Latitudine").getValue()));
                        float lng = Float.parseFloat(String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Longitudine").getValue()));
                        String monday = String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Lunedì").getValue());
                        String tuesday = String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Martedì").getValue());
                        String wednesday = String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Mercoledì").getValue());
                        String thursday = String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Giovedì").getValue());
                        String friday = String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Venerdì").getValue());
                        String saturday = String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Sabato").getValue());
                        String sunday = String.valueOf(dataSnapshot.child(String.valueOf(i)).child("Domenica").getValue());
                        dumpArrayList.add(new Dump(name, address, lat, lng, monday, tuesday, wednesday, thursday, friday, saturday, sunday));
                    }
                    dumpResponseCallback.onSuccessFromRemoteDatabase(dumpArrayList);
                }
            }
        });

        return null;
    }
}
