package com.example.leap.data.source.news;

import static com.example.leap.util.Constants.API_KEY_ERROR;
import static com.example.leap.util.Constants.RETROFIT_ERROR;
import static com.example.leap.util.Constants.TOP_HEADLINES_PAGE_SIZE_VALUE;

import androidx.annotation.NonNull;

import com.example.leap.data.service.NewsApiService;
import com.example.leap.model.NewsApiResponse;
import com.example.leap.util.ServiceLocator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewsRemoteDataSource extends BaseNewsRemoteDataSource {

    private final NewsApiService newsApiService;
    private final String apiKey;

    public NewsRemoteDataSource(String apiKey) {
        this.apiKey = apiKey;
        this.newsApiService = ServiceLocator.getInstance().getNewsApiService();
    }

    @Override
    public void getNews(String country, int page) {
        Call<NewsApiResponse> newsResponseCall = newsApiService.getNews(country,
                TOP_HEADLINES_PAGE_SIZE_VALUE, page, apiKey);

        newsResponseCall.enqueue(new Callback<NewsApiResponse>() {
            @Override
            public void onResponse(@NonNull Call<NewsApiResponse> call,
                                   @NonNull Response<NewsApiResponse> response) {

                if (response.body() != null && response.isSuccessful() &&
                        !response.body().getStatus().equals("error")) {
                    newsCallback.onSuccessFromRemote(response.body(), System.currentTimeMillis());

                } else {
                    newsCallback.onFailureFromRemote(new Exception(API_KEY_ERROR));
                }
            }

            @Override
            public void onFailure(@NonNull Call<NewsApiResponse> call, @NonNull Throwable t) {
                newsCallback.onFailureFromRemote(new Exception(RETROFIT_ERROR));
            }
        });
    }
}
