package com.example.leap.data.source.news;

import java.util.List;

import com.example.leap.model.News;

public abstract class BaseFavoriteNewsDataSource {

    protected NewsCallback newsCallback;

    public void setNewsCallback(NewsCallback newsCallback) {
        this.newsCallback = newsCallback;
    }

    public abstract void getFavoriteNews();
    public abstract void addFavoriteNews(News news);
    public abstract void synchronizeFavoriteNews(List<News> notSynchronizedNewsList);
    public abstract void deleteFavoriteNews(News news);
    public abstract void deleteAllFavoriteNews();
}
