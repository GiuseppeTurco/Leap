package com.example.leap.ui.main;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.example.leap.data.repository.news.INewsRepositoryWithLiveData;

public class NewsViewModelFactory implements ViewModelProvider.Factory {

    private final INewsRepositoryWithLiveData iNewsRepositoryWithLiveData;

    public NewsViewModelFactory(INewsRepositoryWithLiveData iNewsRepositoryWithLiveData) {
        this.iNewsRepositoryWithLiveData = iNewsRepositoryWithLiveData;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) new NewsViewModel(iNewsRepositoryWithLiveData);
    }
}
