package com.example.leap.data.source.news;

import java.util.List;

import com.example.leap.model.News;
import com.example.leap.model.NewsApiResponse;

public abstract class BaseNewsLocalDataSource {

    protected NewsCallback newsCallback;

    public void setNewsCallback(NewsCallback newsCallback) {
        this.newsCallback = newsCallback;
    }

    public abstract void getNews();
    public abstract void getFavoriteNews();
    public abstract void updateNews(News news);
    public abstract void deleteFavoriteNews();
    public abstract void insertNews(NewsApiResponse newsApiResponse);
    public abstract void insertNews(List<News> newsList);
    public abstract void deleteAll();
}
