package com.example.leap;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AboutUsFragment extends Fragment implements View.OnClickListener{

    private final int aboutUsID;
    RecyclerView recyclerView;
    List<Questions> infoList;

    public AboutUsFragment(int aboutUsID){
        this.aboutUsID = aboutUsID;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_about_us, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recyclerViewAboutUs);
        initData();
        setRecyclerView();
        ImageButton returnButton = view.findViewById(R.id.return_button);
        returnButton.setOnClickListener(this);
    }

    private void setRecyclerView() {
        QuestionsAdapter questionsAdapter = new QuestionsAdapter(infoList);
        recyclerView.setAdapter(questionsAdapter);
        recyclerView.setHasFixedSize(true);
    }

    @Override
    public void onClick(View v) {
        SettingsFragment settingsFragment = new SettingsFragment();
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fl_wrapper, settingsFragment)
                .commit();
    }

    private void initData() {
        infoList = new ArrayList<>();
        infoList.add(new Questions( "Chi siamo", "Leap è un progetto volto al miglioramento delle nostre abitudini per quanto concerne la raccolta differenziata. " +
                "un sistema di gestione dei rifiuti che prevede la separazione e la raccolta di materiali diversi al momento del loro smaltimento. Questo processo serve a diversi scopi importanti:" +
                "\n1) Riduzione dell'inquinamento ambientale: La separazione dei rifiuti consente di ridurre l'inquinamento ambientale, poiché alcuni materiali possono essere riciclati o riutilizzati invece di essere smaltiti in discarica o inceneriti. " +
                "\n2) Conservazione delle risorse: La raccolta differenziata facilita il riciclo di materiali come carta, plastica, vetro e metalli. Riciclare questi materiali permette di risparmiare energia e materie prime, contribuendo a preservare le risorse naturali e a ridurre l'impatto ambientale associato all'estrazione e alla produzione di nuovi materiali." +
                "\n3) Riduzione dei costi di smaltimento: Separare i rifiuti in modo corretto può ridurre i costi associati allo smaltimento dei rifiuti. Il riciclo e il riutilizzo dei materiali consentono di ridurre la quantità di rifiuti che devono essere smaltiti in discarica o inceneriti, riducendo quindi i costi per la gestione dei rifiuti." +
                "\n4) Promozione di un comportamento sostenibile: La raccolta differenziata promuove un comportamento più consapevole e sostenibile tra i cittadini." +
                ""));
        infoList.add(new Questions( "La nostra missione", "Spesso si è indecisi sul come iniziare a fare la raccolta differenziata in modo corretto: Leap si impegna a darti un supporto valido e concreto nel tuo viaggio verso pratiche più sostenibili"));
        infoList.add(new Questions( "Team di sviluppo", "Leap è il frutto del lavoro di tre giovani aspiranti programmatori, studenti dell'Università di Milano Bicocca. L'idea sarebbe quella di implementare un'applicazione utile a migliorare la qualità dell'ambiente che ci circonda, dato che le tematiche dell'inquinamento riguardano da vicino soprattutto le nuove generazioni"));
        infoList.add(new Questions( "Aggiornamenti futuri", "Ci prefiggiamo in futuro di riuscire ad ampliare le funzionalità dell'applicazione, in modo da stimolarne l'uso e renderla sempre più semplice e facile nell'utilizzo."));
    }
}
