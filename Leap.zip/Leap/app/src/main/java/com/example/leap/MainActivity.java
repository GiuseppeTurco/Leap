package com.example.leap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.leap.ui.main.BarcodeFragment;
import com.example.leap.ui.main.MapsFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnItemSelectedListener {

    public static SharedPreferences preferences;
    public static Activity thisActivity;
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        thisActivity = this;
        preferences = getSharedPreferences("com.example.leap.preferences", Context.MODE_PRIVATE);



        bottomNavigationView
                = findViewById(R.id.bottomNavigationView);
        bottomNavigationView
                .setOnItemSelectedListener(this);
        bottomNavigationView.setSelectedItemId(R.id.nav_home);

    }

    HomeFragment homeFragment = new HomeFragment();
    SettingsFragment settingsFragment = new SettingsFragment();
    MapsFragment mapsFragment = new MapsFragment();
    BarcodeFragment barcodeFragment = new BarcodeFragment();

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.nav_home) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_wrapper, homeFragment)
                    .commit();
            return true;
        }
        if (item.getItemId() == R.id.nav_settings) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_wrapper, settingsFragment)
                    .commit();
            return true;
        }
        if (item.getItemId() == R.id.nav_barcode) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_wrapper, barcodeFragment)
                    .commit();
            return true;
        }
        if (item.getItemId() == R.id.nav_map) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_wrapper, mapsFragment)
                    .commit();
            return true;
        }
        return false;
    }
}