package com.example.leap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnItemSelectedListener {


    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView
                = findViewById(R.id.bottomNavigationView);
        bottomNavigationView
                .setOnItemSelectedListener(this);
        bottomNavigationView.setSelectedItemId(R.id.nav_home);


    }

    HomeFragment homeFragment = new HomeFragment();
    SettingsFragment settingsFragment = new SettingsFragment();

    MapFragment mapFragment = new MapFragment();

    BarcodeFragment barcodeFragment = new BarcodeFragment();

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.nav_home) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_wrapper, homeFragment)
                    .commit();
            return true;
        }
        if (item.getItemId() == R.id.nav_settings) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_wrapper, settingsFragment)
                    .commit();
            return true;
        }
        if (item.getItemId() == R.id.nav_barcode) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_wrapper, barcodeFragment)
                    .commit();
            return true;
        }
        if (item.getItemId() == R.id.nav_map) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_wrapper, mapFragment)
                    .commit();
            return true;
        }

        return false;
    }
}