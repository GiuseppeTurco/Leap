package com.example.leap;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String ITEM_TABLE = "ITEM_TABLE";
    public static final String COLUMN_ITEM_NAME = "ITEM_NAME";
    public static final String COLUMN_ITEM_BRAND = "ITEM_BRAND";
    public static final String COLUMN_ITEM_PACKAGING = "ITEM_PACKAGING";
    public static final String COLUMN_ITEM_EAN = "ITEM_EAN";

    public DataBaseHelper(@Nullable Context context) {
        super(context, "item.db", null , 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + ITEM_TABLE + " (" + COLUMN_ITEM_EAN + " LONG, " + COLUMN_ITEM_NAME + " TEXT, " + COLUMN_ITEM_BRAND + " TEXT, " + COLUMN_ITEM_PACKAGING + " TEXT )";
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean addOne(Item item) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ITEM_NAME, item.getProdName());
        cv.put(COLUMN_ITEM_BRAND, item.getBrand());
        cv.put(COLUMN_ITEM_PACKAGING, item.getPackaging());
        cv.put(COLUMN_ITEM_EAN, item.getEan());

        long insert = db.insert(ITEM_TABLE, null, cv);

        return insert >= 0  ?  true : false;
    }


    public List<Item>getAll(){
        List<Item> returnList  = new ArrayList<>();

        //get data from the database
        String queryString = "SELECT * FROM " + ITEM_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor =  db.rawQuery(queryString, null);

        if(cursor.moveToFirst()){
            //if there are res i loop through res
            do{
                String ean = cursor.getString(0);
                String itemName = cursor.getString(1);
                String itemBrand = cursor.getString(2);
                String itemPackaging = cursor.getString(3);
                Item newItem = new Item(ean, itemName, itemBrand, itemPackaging);
                returnList.add(newItem);

            }while (cursor.moveToNext());
        }else{
            //not addind anything in the list
        }
        cursor.close();
        db.close();
        return returnList;
    }
}
