package com.example.leap;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class ProfileActivity extends AppCompatActivity {







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ImageButton ib = findViewById(R.id.return_arrow_2);
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(ProfileActivity.this, MainActivity.class);
                ProfileActivity.this.startActivity(myIntent);
                finish();
            }
        });

        TextView name = findViewById(R.id.user_name);
        TextView surname = findViewById(R.id.user_surname);
        TextView email = findViewById(R.id.user_email);
        TextView comune = findViewById(R.id.user_comune);

        name.setText(MainActivity.preferences.getString("nome",""));
        surname.setText(MainActivity.preferences.getString("cognome",""));
        email.setText(MainActivity.preferences.getString("email",""));
        comune.setText(MainActivity.preferences.getString("comune",""));


        Button logout_button = findViewById(R.id.logout_button);

        logout_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent myIntent = new Intent(ProfileActivity.this, LoginActivity.class);
                ProfileActivity.this.startActivity(myIntent);
                MainActivity.thisActivity.finish();
                finish();
            }
        });
    }
}