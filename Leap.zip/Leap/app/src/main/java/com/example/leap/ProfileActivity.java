package com.example.leap;

import static com.example.leap.util.Constants.COMUNE;
import static com.example.leap.util.Constants.EMAIL_ADDRESS;
import static com.example.leap.util.Constants.ENCRYPTED_SHARED_PREFERENCES_FILE_NAME;
import static com.example.leap.util.Constants.NAME;
import static com.example.leap.util.Constants.PASSWORD;
import static com.example.leap.util.Constants.SURNAME;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.leap.ui.welcome.SplashActivity;
import com.example.leap.ui.welcome.WelcomeActivity;
import com.example.leap.util.DataEncryptionUtil;
import com.google.firebase.auth.FirebaseAuth;

import java.io.IOException;
import java.security.GeneralSecurityException;

public class ProfileActivity extends AppCompatActivity {

    private DataEncryptionUtil dataEncryptionUtil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ImageButton ib = findViewById(R.id.return_arrow_2);
        ib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(ProfileActivity.this, MainActivity.class);
                ProfileActivity.this.startActivity(myIntent);
                finish();
            }
        });

        TextView name = findViewById(R.id.user_name);
        TextView surname = findViewById(R.id.user_surname);
        TextView email = findViewById(R.id.user_email);
        TextView comune = findViewById(R.id.user_comune);

        dataEncryptionUtil = new DataEncryptionUtil(getApplication());

        try {
            name.setText(dataEncryptionUtil.readSecretDataWithEncryptedSharedPreferences(ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, NAME));
            surname.setText(dataEncryptionUtil.readSecretDataWithEncryptedSharedPreferences(ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, SURNAME));
            email.setText(dataEncryptionUtil.readSecretDataWithEncryptedSharedPreferences(ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, EMAIL_ADDRESS));
            comune.setText(dataEncryptionUtil.readSecretDataWithEncryptedSharedPreferences(ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, COMUNE));
        } catch (GeneralSecurityException | IOException e) {
            e.printStackTrace();
        }
        Button logout_button = findViewById(R.id.logout_button);

        logout_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent myIntent = new Intent(ProfileActivity.this, WelcomeActivity.class);
                ProfileActivity.this.startActivity(myIntent);
                MainActivity.thisActivity.finish();
                finish();
            }
        });
    }
}