package com.example.leap.ui.main;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.leap.data.repository.dump.IDumpRepository;
import com.example.leap.data.repository.user.IUserRepository;
import com.example.leap.model.Result;
import com.example.leap.model.User;
import com.example.leap.ui.welcome.UserViewModel;

public class DumpViewModel extends ViewModel {
    private static final String TAG = UserViewModel.class.getSimpleName();

    private final IDumpRepository dumpRepository;
    private MutableLiveData<Result> dumpMutableLiveData;

    public DumpViewModel(IDumpRepository dumpRepository) {
        this.dumpRepository = dumpRepository;
    }

    public MutableLiveData<Result> getDumpMutableLiveData() {
        getDumpData();
        return dumpMutableLiveData;
    }

    private void getDumpData() {
        dumpMutableLiveData = dumpRepository.getDump();
    }
}
