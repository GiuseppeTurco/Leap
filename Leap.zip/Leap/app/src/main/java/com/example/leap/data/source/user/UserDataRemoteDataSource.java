package com.example.leap.data.source.user;

import static com.example.leap.util.Constants.COMUNE;
import static com.example.leap.util.Constants.EMAIL_ADDRESS;
import static com.example.leap.util.Constants.FIREBASE_FAVORITE_NEWS_COLLECTION;
import static com.example.leap.util.Constants.FIREBASE_REALTIME_DATABASE;
import static com.example.leap.util.Constants.FIREBASE_USERS_COLLECTION;
import static com.example.leap.util.Constants.NAME;
import static com.example.leap.util.Constants.SHARED_PREFERENCES_COUNTRY_OF_INTEREST;
import static com.example.leap.util.Constants.SHARED_PREFERENCES_FILE_NAME;
import static com.example.leap.util.Constants.SHARED_PREFERENCES_TOPICS_OF_INTEREST;
import static com.example.leap.util.Constants.SURNAME;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.example.leap.model.User;
import com.example.leap.util.SharedPreferencesUtil;

/**
 * Class that gets the user information using Firebase Realtime Database.
 */
public class UserDataRemoteDataSource extends BaseUserDataRemoteDataSource {

    private static final String TAG = UserDataRemoteDataSource.class.getSimpleName();

    private final DatabaseReference databaseReference;
    private final SharedPreferencesUtil sharedPreferencesUtil;

    public UserDataRemoteDataSource(SharedPreferencesUtil sharedPreferencesUtil) {
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance(FIREBASE_REALTIME_DATABASE);
        databaseReference = firebaseDatabase.getReference().getRef();
        this.sharedPreferencesUtil = sharedPreferencesUtil;
    }

    @Override
    public User getUserdata(String idToken) {
        databaseReference.child(FIREBASE_USERS_COLLECTION).child(idToken).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e(TAG, "Error getting data");
                }
                else {
                    DataSnapshot dataSnapshot = task.getResult();
                    String name = String.valueOf(dataSnapshot.child(NAME).getValue());
                    String surname = String.valueOf(dataSnapshot.child(SURNAME).getValue());
                    String email = String.valueOf(dataSnapshot.child(EMAIL_ADDRESS).getValue());
                    String comune = String.valueOf(dataSnapshot.child(COMUNE).getValue());
                    userResponseCallback.onSuccessFromRemoteDatabase(new User(name, surname, email, comune, idToken));
                }
            }
        });

        return null;
    }
}
