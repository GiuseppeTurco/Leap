package com.example.leap.data.source.item;


import static com.example.leap.util.Constants.FIREBASE_ITEM_COLLECTION;
import static com.example.leap.util.Constants.FIREBASE_REALTIME_DATABASE;

import android.util.Log;

import androidx.annotation.NonNull;

import com.example.leap.data.source.dump.BaseDumpDataRemoteDataSource;
import com.example.leap.model.Dump;
import com.example.leap.model.Item;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class ItemDataRemoteDataSource extends BaseItemDataRemoteDataSource {

    private static final String TAG = ItemDataRemoteDataSource.class.getSimpleName();


    private final DatabaseReference databaseReference;

    public ItemDataRemoteDataSource() {
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance(FIREBASE_REALTIME_DATABASE);
        databaseReference = firebaseDatabase.getReference().getRef();
    }

    @Override
    public Item getItem(Long ean) {
        databaseReference.child(FIREBASE_ITEM_COLLECTION).child(String.valueOf(ean)).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e(TAG, "Error getting data");
                    itemCallback.onFailureFromRemoteDatabase("Error getting data");
                }
                else {
                    DataSnapshot dataSnapshot = task.getResult();
                    String brand = String.valueOf(dataSnapshot.child("Brand").getValue());
                    String packaging = String.valueOf(dataSnapshot.child("Packaging").getValue());
                    String name = String.valueOf(dataSnapshot.child("Name").getValue());


                    itemCallback.onSuccessFromRemoteDatabase(new Item(ean, name, brand, packaging ));
                }
            }
        });

        return null;
    }

}
