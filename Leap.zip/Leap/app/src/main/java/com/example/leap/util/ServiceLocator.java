package com.example.leap.util;

import android.app.Application;

import com.example.leap.data.database.ItemDatabase;
/*import com.example.leap.data.database.NewsRoomDatabase;
import com.example.leap.data.repository.news.INewsRepositoryWithLiveData;
import com.example.leap.data.repository.news.NewsRepositoryWithLiveData;*/
import com.example.leap.data.repository.dump.DumpRepository;
import com.example.leap.data.repository.dump.IDumpRepository;
import com.example.leap.data.repository.item.IItemRepository;
import com.example.leap.data.repository.item.ItemRepository;
import com.example.leap.data.repository.user.IUserRepository;
import com.example.leap.data.repository.user.UserRepository;
/*import com.example.leap.data.service.NewsApiService;
import com.example.leap.data.source.news.BaseFavoriteNewsDataSource;
import com.example.leap.data.source.news.BaseNewsLocalDataSource;
import com.example.leap.data.source.news.BaseNewsRemoteDataSource;
import com.example.leap.data.source.news.FavoriteNewsDataSource;
import com.example.leap.data.source.news.NewsLocalDataSource;
import com.example.leap.data.source.news.NewsMockRemoteDataSource;
import com.example.leap.data.source.news.NewsRemoteDataSource;*/
import com.example.leap.data.source.dump.BaseDumpDataRemoteDataSource;
import com.example.leap.data.source.dump.DumpDataRemoteDataSource;
import com.example.leap.data.source.item.BaseItemDataRemoteDataSource;
import com.example.leap.data.source.item.ItemDataRemoteDataSource;
import com.example.leap.data.source.item.ItemLocalDataSource;
import com.example.leap.data.source.user.BaseUserAuthenticationRemoteDataSource;
import com.example.leap.data.source.user.BaseUserDataRemoteDataSource;
import com.example.leap.data.source.user.UserAuthenticationRemoteDataSource;
import com.example.leap.data.source.user.UserDataRemoteDataSource;

/**
 *  Registry to provide the dependencies for the classes
 *  used in the application.
 */
public class ServiceLocator {

    private static volatile ServiceLocator INSTANCE = null;

    private ServiceLocator() {}

    public static ServiceLocator getInstance() {
        if (INSTANCE == null) {
            synchronized(ServiceLocator.class) {
                if (INSTANCE == null) {
                    INSTANCE = new ServiceLocator();
                }
            }
        }
        return INSTANCE;
    }

    public IUserRepository getUserRepository(Application application) {
        SharedPreferencesUtil sharedPreferencesUtil = new SharedPreferencesUtil(application);

        BaseUserAuthenticationRemoteDataSource userRemoteAuthenticationDataSource =
                new UserAuthenticationRemoteDataSource();

        BaseUserDataRemoteDataSource userDataRemoteDataSource =
                new UserDataRemoteDataSource(sharedPreferencesUtil);

        DataEncryptionUtil dataEncryptionUtil = new DataEncryptionUtil(application);


        return new UserRepository(userRemoteAuthenticationDataSource,
                userDataRemoteDataSource);
    }

    public IDumpRepository getDumpRepository(Application application) {

        BaseDumpDataRemoteDataSource dumpDataRemoteDataSource =
                new DumpDataRemoteDataSource();



        return new DumpRepository(dumpDataRemoteDataSource);
    }

    public IItemRepository getItemRepository(Application application) {

        BaseItemDataRemoteDataSource itemDataRemoteDataSource =
                new ItemDataRemoteDataSource();


        ItemLocalDataSource itemLocalDataSource =new ItemLocalDataSource(getItemDao(application));
        return new ItemRepository(itemDataRemoteDataSource, itemLocalDataSource);
    }
    public ItemDatabase getItemDao(Application application) {
        return ItemDatabase.getDatabase(application);
    }

}
