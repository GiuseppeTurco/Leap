package com.example.leap;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class LoginActivity extends AppCompatActivity {

    EditText editTextEmail;
    EditText editTextPassword;
    Button buttonLogin;
    TextView registerTextView;
    FirebaseAuth mAuth;
    FirebaseDatabase db;
    DatabaseReference reference;

    @Override
    public void onStart() {
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            Intent myIntent = new Intent(LoginActivity.this, MainActivity.class);
            LoginActivity.this.startActivity(myIntent);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();
        editTextEmail = findViewById(R.id.editText_email);
        editTextPassword = findViewById(R.id.editText_password);
        buttonLogin = findViewById(R.id.login_button);

        registerTextView = findViewById(R.id.register_text);

        Button btn_facebook = findViewById(R.id.facebook);
        Button btn_google = findViewById(R.id.google);

        btn_facebook.setOnClickListener(v-> Toast.makeText(LoginActivity.this, "Coming Soon...", Toast.LENGTH_SHORT).show());
        btn_google.setOnClickListener(v-> Toast.makeText(LoginActivity.this, "Coming Soon...", Toast.LENGTH_SHORT).show());

        registerTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(LoginActivity.this, RegisterActivity.class);
                LoginActivity.this.startActivity(myIntent);
            }
        });

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email, password;
                email= String.valueOf(editTextEmail.getText());
                password= String.valueOf(editTextPassword.getText());

                if(TextUtils.isEmpty(email)||TextUtils.isEmpty(password)){
                    Toast.makeText(LoginActivity.this, "Tutti i campi devono essere riempiti", Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(LoginActivity.this, "L'autenticazione ha avuto successo", Toast.LENGTH_SHORT).show();
                                    SharedPreferences preferences = getSharedPreferences("com.example.leap.preferences", Context.MODE_PRIVATE);
                                    SharedPreferences.Editor editor = preferences.edit();
                                    db = FirebaseDatabase.getInstance();
                                    reference = FirebaseDatabase.getInstance().getReference("Utenti");
                                    reference.child(email.replace(".","_")).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                                        @Override
                                        public void onComplete(@NonNull Task<DataSnapshot> task) {
                                            if(task.isSuccessful() && task.getResult().exists()){
                                                DataSnapshot dataSnapshot = task.getResult();
                                                String name = String.valueOf(dataSnapshot.child("name").getValue());
                                                String surname = String.valueOf(dataSnapshot.child("surname").getValue());
                                                String comune = String.valueOf(dataSnapshot.child("comune").getValue());
                                                editor.putString("nome", name);
                                                editor.putString("cognome", surname);
                                                editor.putString("email", email.replace("_","."));
                                                editor.putString("comune", comune);
                                                editor.commit();
                                            }
                                        }
                                    });
                                    Intent myIntent = new Intent(LoginActivity.this, MainActivity.class);
                                    LoginActivity.this.startActivity(myIntent);
                                    finish();
                                } else {
                                    Toast.makeText(LoginActivity.this, "L'autenticazione è fallita", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }
}