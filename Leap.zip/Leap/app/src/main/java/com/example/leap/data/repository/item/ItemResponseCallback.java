package com.example.leap.data.repository.item;

import com.example.leap.model.Item;

public interface ItemResponseCallback {
    void onSuccessFromRemoteDatabase(Item item);
    void onFailureFromRemoteDatabase(String message);
}
