package com.example.leap;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class HomeFragment extends Fragment {

    private Context thiscontext;
    private RecyclerView newsRV;
    private ProgressBar loadingPB;
    private ArrayList<Articles> articlesArrayList;
    private NewsRVAdapter newsRVAdapter;
    private ImageButton profileButton;

    public HomeFragment() {
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        thiscontext = container.getContext();
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        profileButton = rootView.findViewById(R.id.ibProfile);
        profileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(container.getContext(), ProfileActivity.class));
            }
        });

        newsRV = rootView.findViewById(R.id.idRVNews);
        loadingPB = rootView.findViewById(R.id.idPBLoading);
        articlesArrayList = new ArrayList<>();
        newsRVAdapter = new NewsRVAdapter(articlesArrayList, getActivity());
        newsRV.setLayoutManager(new LinearLayoutManager(getActivity()));
        newsRV.setAdapter(newsRVAdapter);
        getNews();
        newsRVAdapter.notifyDataSetChanged();
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

    }

    private void getNews(){
        loadingPB.setVisibility(View.VISIBLE);
        articlesArrayList.clear();

        String newsURL;
        String BASE_URL;

        if(Locale.getDefault().getLanguage().equals("it")){
            newsURL = "https://newsdata.io/api/1/news?apikey=pub_34900469435bee763a92ad2baaea7f330759e&category=environment&language=it&country=it";
            BASE_URL = "https://newsdata.io/";
        }else{
            newsURL = "https://newsdata.io/api/1/news?apikey=pub_34900469435bee763a92ad2baaea7f330759e&category=environment&language=en";
            BASE_URL = "https://newsdata.io/";
        }

        Retrofit retrofit = new Retrofit.Builder().baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RetrofitAPI retrofitAPI = retrofit.create(RetrofitAPI.class);
        Call<NewsModal> call;
        call = retrofitAPI.getNews(newsURL);
        call.enqueue(new Callback<NewsModal>() {
            @Override
            public void onResponse(@NonNull Call<NewsModal> call, @NonNull Response<NewsModal> response) {
                NewsModal newsModal;
                newsModal = response.body();
                loadingPB.setVisibility(View.GONE);
                ArrayList<Articles> articles = newsModal.getResults();
                int i;
                for(i=0; articles.size() > i; i++){
                    articlesArrayList.add(new Articles(articles.get(i).getTitle(),articles.get(i).getDescription(), articles.get(i).getImage_url(),
                            articles.get(i).getLink(),articles.get(i).getContent()));
                    newsRVAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(@NonNull Call<NewsModal> call, @NonNull Throwable t) {
                requireActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(requireActivity(), "Fail to get news", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }
}