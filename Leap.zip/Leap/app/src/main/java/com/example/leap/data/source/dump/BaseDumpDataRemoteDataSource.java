package com.example.leap.data.source.dump;

import com.example.leap.data.repository.dump.DumpResponseCallback;
import com.example.leap.data.repository.user.UserResponseCallback;
import com.example.leap.model.Dump;
import com.example.leap.model.User;

import java.util.ArrayList;

public abstract class BaseDumpDataRemoteDataSource {
    protected DumpResponseCallback dumpResponseCallback;

    public void setDumpResponseCallback(DumpResponseCallback dumpResponseCallback) {
        this.dumpResponseCallback = dumpResponseCallback;
    }

    public abstract ArrayList<Dump> getDump();
}
