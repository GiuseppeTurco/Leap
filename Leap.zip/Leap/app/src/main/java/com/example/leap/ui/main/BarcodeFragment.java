package com.example.leap.ui.main;

import android.app.Application;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.example.leap.R;
import com.example.leap.ItemRecyclerViewAdapter;
import com.example.leap.data.database.ItemDatabase;
import com.example.leap.data.repository.item.IItemRepository;
import com.example.leap.data.repository.item.ItemRepository;
import com.example.leap.data.source.item.BaseItemDataRemoteDataSource;
import com.example.leap.data.source.item.ItemDataRemoteDataSource;
import com.example.leap.data.source.item.ItemLocalDataSource;
import com.example.leap.databinding.FragmentBarcodeBinding;
import com.example.leap.model.Item;
import com.example.leap.model.Result;
import com.example.leap.util.ErrorMessagesUtil;
import com.example.leap.util.ServiceLocator;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class BarcodeFragment extends Fragment {

    ImageButton scanButton;
    Context thiscontext;
    SwipeRefreshLayout swipeRefreshLayout;
    View view;
    private BarcodeViewModel itemViewModel;
    private Application application;
    private FragmentBarcodeBinding fragmentBarcodeBinding;

    private List<Item> itemList;
    private ItemRecyclerViewAdapter itemRecyclerViewAdapter;
    boolean bool = true;
    private IItemRepository itemRepository;
    private ItemLocalDataSource itemLocalDataSource;
    private BaseItemDataRemoteDataSource baseItemDataRemoteDataSource;
    Item item;





    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        itemList = new ArrayList<>();

        IItemRepository itemRepositoryWithLiveData =
                ServiceLocator.getInstance().getItemRepository(
                        requireActivity().getApplication());


        if (itemRepositoryWithLiveData != null) {
            // This is the way to create a ViewModel with custom parameters
            // (see NewsViewModelFactory class for the implementation details)
            itemViewModel = new ViewModelProvider(requireActivity(), new BarcodeViewModelFactory(itemRepository, requireActivity().getApplication())).get(BarcodeViewModel.class);
        } else {
            Snackbar.make(requireActivity().findViewById(android.R.id.content),
                    getString(R.string.unexpected_error), Snackbar.LENGTH_SHORT).show();
        }
        itemList = new ArrayList<>();




    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        fragmentBarcodeBinding = FragmentBarcodeBinding.inflate(inflater, container, false);

        return fragmentBarcodeBinding.getRoot();
    }



    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        application = requireActivity().getApplication();
        itemLocalDataSource = new ItemLocalDataSource(ItemDatabase.getDatabase(getContext()));
        baseItemDataRemoteDataSource = new ItemDataRemoteDataSource();

        itemRepository = new ItemRepository(baseItemDataRemoteDataSource, itemLocalDataSource);





        // Get the button view from the layout
        scanButton = view.findViewById(R.id.bScan);


        RecyclerView recyclerView = view.findViewById(R.id.lv_item_list);

        // Set up the click listener for the scan button
        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BarcodeReadFragment barcodeReadFragment = new BarcodeReadFragment();
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fl_wrapper, barcodeReadFragment)
                        .commit();
            }
        });

        // Initialize the SwipeRefreshLayout object

        swipeRefreshLayout = getView().findViewById(R.id.swipeRefreshLayout);
        updateReyclerView(itemList, view);

        // Check if the SwipeRefreshLayout object is not null
        if (swipeRefreshLayout != null) {
            // Set the OnRefreshListener

            swipeRefreshLayout.setOnRefreshListener(() -> {
                // Do something when the swipe refresh layout is refreshed
                updateReyclerView(itemList,view);
                swipeRefreshLayout.setRefreshing(false);
            });
        } else {
            // Handle the case where the swipe refresh layout is null
            Snackbar.make(requireActivity().findViewById(android.R.id.content),
                    "cannot load swiperefresher", Snackbar.LENGTH_SHORT).show();
        }

    }





    public void updateReyclerView(List<Item> itemList, View view ){

        RecyclerView recyclerViewItems = view.findViewById(R.id.lv_item_list);
        LinearLayoutManager layoutManager =
                new LinearLayoutManager(requireContext(),
                        LinearLayoutManager.VERTICAL, false);

        itemRecyclerViewAdapter =
                new ItemRecyclerViewAdapter(requireContext(), application, itemList);
        recyclerViewItems.setAdapter(itemRecyclerViewAdapter);

        recyclerViewItems.setLayoutManager(layoutManager);
        recyclerViewItems.setAdapter(itemRecyclerViewAdapter);

        itemViewModel.getItemsMutableLiveData().observe(getViewLifecycleOwner(),
                result -> {
                    if (result.isSuccess()) {
                        List<Item> itemList1 = ((Result.ItemResponseSuccess)result).getDataList();
                        this.itemList = itemList1;


                    } else {
                        ErrorMessagesUtil errorMessagesUtil =
                                new ErrorMessagesUtil(requireActivity().getApplication());
                        Snackbar.make(view, errorMessagesUtil.
                                        getErrorMessage(((Result.Error)result).getMessage()),
                                Snackbar.LENGTH_SHORT).show();
                    }
                });


    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        itemViewModel.setFirstLoading(true);
        itemViewModel.setLoading(false);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        fragmentBarcodeBinding = null;
    }



}