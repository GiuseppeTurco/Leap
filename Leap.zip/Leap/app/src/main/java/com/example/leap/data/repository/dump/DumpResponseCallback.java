package com.example.leap.data.repository.dump;

import com.example.leap.model.Dump;

import java.util.ArrayList;

public interface DumpResponseCallback {

    void onSuccessFromRemoteDatabase(ArrayList<Dump> dump);
    void onFailureFromRemoteDatabase(String message);
}
