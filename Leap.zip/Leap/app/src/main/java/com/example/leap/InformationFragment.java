package com.example.leap;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class InformationFragment extends Fragment implements View.OnClickListener {

    private int informationID;
    Context thiscontext;

    public InformationFragment(int informationID){
        this.informationID = informationID;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        thiscontext=container.getContext();
        if(MainActivity.preferences.getBoolean("isDark", false)){
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }else{
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
        return inflater.inflate(R.layout.fragment_information, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView informationText = view.findViewById(R.id.informationText);
        setInformationText(informationText);
        Button returnButton = view.findViewById(R.id.return_button);
        returnButton.setOnClickListener(this);
    }


    private void setInformationText(TextView t){
        if (informationID == R.id.contact_us_text) {
            t.setText("Per eventuali problemi con l'applicazione Leap è possibile contattare il centralino al numero 1234567890 oppure \n è disponibile il supporto tecnico alla mail leap@gmail.com.");
        }

        if (informationID == R.id.about_us_text) {
            t.setText("Leap è un progetto sviluppato per essere un supporto alla vita quotidiana di ognuno di noi. \n Si prepone come scopo di aiutare il cittadino nella raccolta differenziata e \n lo informa di dove sono localizzate le discariche attorno a lui.");
        }

        if (informationID == R.id.faq_text) {
            t.setText("1. domanda? \n risposta \n 2. domanda? \n riposta");
        }
    }

    @Override
    public void onClick(View v) {
        SettingsFragment settingsFragment = new SettingsFragment();
        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.fl_wrapper, settingsFragment)
                .commit();
    }
}