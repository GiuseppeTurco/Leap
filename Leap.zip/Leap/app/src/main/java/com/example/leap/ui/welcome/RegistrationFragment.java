package com.example.leap.ui.welcome;

import static com.example.leap.util.Constants.COMUNE;
import static com.example.leap.util.Constants.EMAIL_ADDRESS;
import static com.example.leap.util.Constants.ENCRYPTED_DATA_FILE_NAME;
import static com.example.leap.util.Constants.ENCRYPTED_SHARED_PREFERENCES_FILE_NAME;
import static com.example.leap.util.Constants.ID_TOKEN;
import static com.example.leap.util.Constants.MINIMUM_PASSWORD_LENGTH;
import static com.example.leap.util.Constants.NAME;
import static com.example.leap.util.Constants.PASSWORD;
import static com.example.leap.util.Constants.SURNAME;
import static com.example.leap.util.Constants.USER_COLLISION_ERROR;
import static com.example.leap.util.Constants.WEAK_PASSWORD_ERROR;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.leap.databinding.FragmentRegistrationBinding;
import com.example.leap.ui.main.MainActivity;
import com.google.android.material.snackbar.Snackbar;

import org.apache.commons.validator.routines.EmailValidator;

import java.io.IOException;
import java.security.GeneralSecurityException;

import com.example.leap.R;
import com.example.leap.model.Result;
import com.example.leap.model.User;
import com.example.leap.util.DataEncryptionUtil;

/**
 * Fragment that allows the user to create an account.
 */
public class RegistrationFragment extends Fragment {

    private static final String TAG = RegistrationFragment.class.getSimpleName();

    private FragmentRegistrationBinding binding;
    private UserViewModel userViewModel;
    private DataEncryptionUtil dataEncryptionUtil;

    public RegistrationFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment RegistrationFragment.
     */
    public static RegistrationFragment newInstance() {
        return new RegistrationFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        userViewModel = new ViewModelProvider(requireActivity()).get(UserViewModel.class);
        userViewModel.setAuthenticationError(false);
        dataEncryptionUtil = new DataEncryptionUtil(requireActivity().getApplication());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding = FragmentRegistrationBinding.inflate(inflater, container, false);

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.registerButton.setOnClickListener(v -> {
            String name = binding.insertName.getText().toString().trim();
            String surname = binding.insertSurname.getText().toString().trim();
            String email = binding.insertEmail.getText().toString().trim();
            String password = binding.insertPassword.getText().toString().trim();
            String comune = binding.insertComune.getText().toString().trim();

            if (isEmailOk(email) & isPasswordOk(password) & isOtherOk(name, surname, comune)) {
                if (!userViewModel.isAuthenticationError()) {
                    userViewModel.getUserMutableLiveData(name, surname, email, password, comune, false).observe(
                            getViewLifecycleOwner(), result -> {
                                if (result.isSuccess()) {
                                    User user = ((Result.UserResponseSuccess) result).getData();
                                    saveLoginData(name, surname, email, password, comune, user.getIdToken());
                                    userViewModel.setAuthenticationError(false);
                                    Intent myIntent = new Intent(getActivity(), MainActivity.class);
                                    RegistrationFragment.this.startActivity(myIntent);
                                    getActivity().finish();
                                } else {
                                    userViewModel.setAuthenticationError(true);
                                    Snackbar.make(requireActivity().findViewById(android.R.id.content),
                                            getErrorMessage(((Result.Error) result).getMessage()),
                                            Snackbar.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    userViewModel.getUser(email, password, false);
                }
            } else {
                userViewModel.setAuthenticationError(true);
                Snackbar.make(requireActivity().findViewById(android.R.id.content),
                        R.string.check_login_data_message, Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    private String getErrorMessage(String message) {
        switch(message) {
            case WEAK_PASSWORD_ERROR:
                return requireActivity().getString(R.string.error_password);
            case USER_COLLISION_ERROR:
                return requireActivity().getString(R.string.error_user_collision_message);
            default:
                return requireActivity().getString(R.string.unexpected_error);
        }
    }

    /**
     * Checks if the email address has a correct format.
     * @param email The email address to be validated
     * @return true if the email address is valid, false otherwise
     */
    private boolean isEmailOk(String email) {
        // Check if the email is valid through the use of this library:
        // https://commons.apache.org/proper/commons-validator/
        if (!EmailValidator.getInstance().isValid((email))) {
            binding.insertEmail.setError(getString(R.string.error_email));
            return false;
        } else {
            binding.insertEmail.setError(null);
            return true;
        }
    }

    private boolean isOtherOk(String name, String surname, String comune) {

        boolean f= true;

        if(name.isEmpty()){
            binding.insertName.setError(getString(R.string.error_name));
            f=false;
        }else {
            binding.insertName.setError(null);
        }

        if(surname.isEmpty()){
            binding.insertSurname.setError(getString(R.string.error_surname));
            f=false;
        }else {
            binding.insertSurname.setError(null);
        }

        if(comune.isEmpty()){
            binding.insertComune.setError(getString(R.string.error_comune));
            f=false;
        }else {
            binding.insertComune.setError(null);
        }

        return f;
    }

    /**
     * Checks if the password is not empty.
     * @param password The password to be checked
     * @return True if the password has at least 6 characters, false otherwise
     */
    private boolean isPasswordOk(String password) {
        // Check if the password length is correct
        if (password.isEmpty() || password.length() < MINIMUM_PASSWORD_LENGTH) {
            binding.insertPassword.setError(getString(R.string.error_password));
            return false;
        } else {
            binding.insertPassword.setError(null);
            return true;
        }
    }

    /**
     * Encrypts login data using DataEncryptionUtil class.
     * @param email The email address to be encrypted and saved
     * @param password The password to be encrypted and saved
     * @param idToken The token associated with the account
     */
    private void saveLoginData(String name, String surname, String email, String password, String comune, String idToken) {
        try {
            dataEncryptionUtil.writeSecretDataWithEncryptedSharedPreferences(
                    ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, NAME, name);
            dataEncryptionUtil.writeSecretDataWithEncryptedSharedPreferences(
                    ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, SURNAME, surname);
            dataEncryptionUtil.writeSecretDataWithEncryptedSharedPreferences(
                    ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, EMAIL_ADDRESS, email);
            dataEncryptionUtil.writeSecretDataWithEncryptedSharedPreferences(
                    ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, PASSWORD, password);
            dataEncryptionUtil.writeSecretDataWithEncryptedSharedPreferences(
                    ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, COMUNE, comune);
            dataEncryptionUtil.writeSecretDataWithEncryptedSharedPreferences(
                    ENCRYPTED_SHARED_PREFERENCES_FILE_NAME, ID_TOKEN, idToken);
            dataEncryptionUtil.writeSecreteDataOnFile(ENCRYPTED_DATA_FILE_NAME,
                    email.concat(":").concat(password));
        } catch (GeneralSecurityException | IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}