package com.example.leap.ui.main;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.leap.R;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ContactFragment extends Fragment implements View.OnClickListener{

    RecyclerView recyclerView;
    List<Questions> infoList;

    public ContactFragment(){}


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_contact, container, false);
    }

    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recyclerViewAboutUs);

        initData();
        setRecyclerView();
        ImageButton returnButton = view.findViewById(R.id.return_arrow_4);
        returnButton.setOnClickListener(this);
    }

    private void setRecyclerView() {
        QuestionsAdapter questionsAdapter = new QuestionsAdapter(infoList);
        recyclerView.setAdapter(questionsAdapter);
        recyclerView.setHasFixedSize(true);
    }

    @Override
    public void onClick(View v) {
        Navigation.findNavController(v).navigate(R.id.action_contactFragment_to_settingsFragment);
    }

    private void initData() {
        infoList = new ArrayList<>();
        if(Locale.getDefault().getLanguage().equals("it")){
            infoList.add(new Questions( "Indirizzo mail", "Per qualsiasi esigenza puoi rivolgerti a noi scrivendo alla seguente mail:" +
                    "\nLeapProject@gmail.com" +
                    "\nCercheremo di dare una risposta appena possibile"));
            infoList.add(new Questions( "Numero di telefono", "Puoi rivolgerti al seguente numero nei giorni e orari specificati:" +
                    "\n3454781899" +
                    "\nLunedì   9:00-12:30" +
                    "\nGiovedì  10:00-12:30"));
            infoList.add(new Questions( "Politica sulla privacy", "Possiamo raccogliere, in base ai servizi da te attivati all'interno dell'App Junker, le seguenti informazioni, classificabili come dati personali ai sensi dell'art. 4 regolamento UE 2016/679:" +
                    "\nnome e cognome dell'utente;" +
                    "\nindirizzo email;" +
                    "\nidentificatori: identificatori univoci del dispositivo (device id);" +
                    "\nimpostazioni del dispositivo: informazioni che riceviamo tramite le impostazioni del dispositivo attivate dall'utente, come l'accesso a posizione GPS, fotocamera o foto;" +
                    "per alcune funzionalità, come ad esempio per le segnalazioni degrado, latitudine, longitudine, accuracy e identificativo utenza con via, civico e singola utenza." +
                    "\nLe modalità di raccolta possono avvenire attraverso il conferimento dei dati diretto da parte dell'utente o dai cellulari e/o tablet su cui l'utente utilizza l'applicazione al fine di consentire il funzionamento del servizio e per l'utilizzazione di alcune funzioni del device."));
        }else{
            infoList.add(new Questions( "Email address", "For any need, you can contact us by writing to the following email:" +
                    "\nLeapProject@gmail.com" +
                    "\nWe will try to provide a response as soon as possible."));
            infoList.add(new Questions( "Telephone number", "You can contact the following number on the specified days and times:" +
                    "\n3454781899" +
                    "\nMonday   9:00-12:30" +
                    "\nThursday  10:00-12:30"));
            infoList.add(new Questions( "Privacy policy", "We can collect, based on the services activated within the Junker App, the following information, classifiable as personal data pursuant to EU Regulation 2016/679, Article 4:" +
                    "\nuser's name and surname;" +
                    "\nemail address;" +
                    "\nIdentifiers: Unique identifiers of the device (device id);" +
                    "\nDevice settings: Information we receive through user-enabled device settings, such as access to GPS location, camera, or photos;" +
                    "For certain features, such as degradation reports, latitude, longitude, accuracy, and user identifier with street, civic number, and individual user." +
                    "\nThe collection methods can occur through the direct provision of data by the user or from the mobile phones and/or tablets on which the user uses the application to allow the service to function and for the use of some device functions."));
        }
    }
}
