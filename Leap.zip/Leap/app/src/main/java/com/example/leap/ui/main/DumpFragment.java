package com.example.leap.ui.main;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.leap.R;
import com.example.leap.model.Dump;

public class DumpFragment extends Fragment {


    private Dump dump;

    public DumpFragment(Dump dump){
        this.dump = dump;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_dump, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageButton button = view.findViewById(R.id.return_arrow_7);
        TextView nameV = view.findViewById(R.id.name_view);
        TextView addressV = view.findViewById(R.id.address_view);
        TextView mondayV = view.findViewById(R.id.monday_view);
        TextView tuesdayV = view.findViewById(R.id.tuesday_view);
        TextView wednesdayV = view.findViewById(R.id.wednesday_view);
        TextView thursdayV = view.findViewById(R.id.thursday_view);
        TextView fridayV = view.findViewById(R.id.friday_view);
        TextView saturdayV = view.findViewById(R.id.saturday_view);
        TextView sundayV = view.findViewById(R.id.sunday_view);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MapsFragment mapsFragment = new MapsFragment();
                getActivity().getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fl_wrapper, mapsFragment)
                        .commit();
            }
        });

        nameV.setText(dump.getName());
        addressV.setText(dump.getAddress());
        mondayV.setText(dump.getMonday());
        tuesdayV.setText(dump.getTuesday());
        wednesdayV.setText(dump.getWednesday());
        thursdayV.setText(dump.getTuesday());
        fridayV.setText(dump.getFriday());
        saturdayV.setText(dump.getSaturday());
        sundayV.setText(dump.getSunday());
    }
}