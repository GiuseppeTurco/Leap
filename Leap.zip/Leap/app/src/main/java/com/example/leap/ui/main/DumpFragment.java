package com.example.leap.ui.main;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.example.leap.R;
import com.example.leap.databinding.FragmentDumpBinding;
import com.example.leap.databinding.FragmentNewsDetailBinding;
import com.example.leap.model.Dump;
import com.example.leap.model.News;

public class DumpFragment extends Fragment {


    private Dump dump;
    private FragmentDumpBinding fragmentDumpBinding;

    public DumpFragment() {}

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentDumpBinding = FragmentDumpBinding.inflate(inflater, container, false);
        return fragmentDumpBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dump = DumpFragmentArgs.fromBundle(getArguments()).getDump();

        fragmentDumpBinding.returnArrow7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_dumpFragment_to_mapsFragment);
            }
        });

        fragmentDumpBinding.nameView.setText(dump.getName());
        fragmentDumpBinding.addressView.setText(dump.getAddress());
        fragmentDumpBinding.mondayView.setText(dump.getMonday());
        fragmentDumpBinding.tuesdayView.setText(dump.getTuesday());
        fragmentDumpBinding.wednesdayView.setText(dump.getWednesday());
        fragmentDumpBinding.thursdayView.setText(dump.getTuesday());
        fragmentDumpBinding.fridayView.setText(dump.getFriday());
        fragmentDumpBinding.saturdayView.setText(dump.getSaturday());
        fragmentDumpBinding.sundayView.setText(dump.getSunday());
    }
}