package com.example.leap.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "Item")
public class Item implements Parcelable {


    @PrimaryKey(autoGenerate = true)
    public int ID;

    @ColumnInfo(name = "Item_ean")
    Long ean;

    @ColumnInfo(name= "prodName")
    String prodName;

    @ColumnInfo(name= "brand")
    String brand;

    @ColumnInfo(name= "packaging")
    String packaging;

    public boolean isSynchronized() {
        return isSynchronized;
    }



    @ColumnInfo(name = "is_synchronized")
    private boolean isSynchronized;



    @Ignore
    public Item() {
    }



    public Item(Long ean, String prodName, String brand, String packaging) {
        this.prodName = prodName;
        this.brand = brand;
        this.packaging = packaging;
        this.ean = ean;
        this.isSynchronized = isSynchronized;
    }

    @Override
    public String toString() {
        return "Item{" +
                "ean=" + ean +
                ", prodName='" + prodName + '\'' +
                ", brand='" + brand + '\'' +
                ", packaging='" + packaging + '\'' +
                '}';
    }

    public Long getEan() {
        return ean;
    }

    public void setEan(Long ean) {
        this.ean = ean;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPackaging() {
        return packaging;
    }

    public void setPackaging(String packaging) {
        this.packaging = packaging;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeLong(this.ean);
        dest.writeString(this.brand);
        dest.writeString(this.packaging);
        dest.writeString(this.prodName);
    }
    public void readFromParcel(Parcel source) {
        this.ean=source.readLong();
        this.brand=source.readString();
        this.packaging=source.readString();
        this.prodName=source.readString();
    }


    protected Item(Parcel in) {
        this.ean=in.readLong();
        this.brand=in.readString();
        this.packaging=in.readString();
        this.prodName=in.readString();
    }

    public static final Creator<Item> CREATOR = new Creator<Item>() {
        @Override
        public Item createFromParcel(Parcel source) {
            return new Item(source);
        }

        @Override
        public Item[] newArray(int size) {
            return new Item[size];
        }
    };

    public void setSynchronized(boolean aSynchronized) {
        isSynchronized = aSynchronized;
    }



    public void setId(Long ean) {
        this.ean = ean;
    }
}
