package com.example.leap.data.repository.dump;

import androidx.lifecycle.MutableLiveData;

import com.example.leap.data.repository.user.UserRepository;
import com.example.leap.data.source.dump.BaseDumpDataRemoteDataSource;
import com.example.leap.data.source.user.BaseUserAuthenticationRemoteDataSource;
import com.example.leap.data.source.user.BaseUserDataRemoteDataSource;
import com.example.leap.model.Dump;
import com.example.leap.model.Result;
import com.example.leap.model.User;

import java.util.ArrayList;

public class DumpRepository implements  IDumpRepository, DumpResponseCallback{
    private static final String TAG = DumpRepository.class.getSimpleName();
    private final BaseDumpDataRemoteDataSource baseDumpDataRemoteDataSource;
    private final MutableLiveData<Result> dumpMutableLiveData;

    public DumpRepository(BaseDumpDataRemoteDataSource baseDumpDataRemoteDataSource) {
        this.baseDumpDataRemoteDataSource = baseDumpDataRemoteDataSource;
        this.dumpMutableLiveData = new MutableLiveData<>();
        this.baseDumpDataRemoteDataSource.setDumpResponseCallback(this);
    }

    @Override
    public void onSuccessFromRemoteDatabase(ArrayList<Dump> dump) {
        Result.DumpResponseSuccess result = new Result.DumpResponseSuccess(dump);
        dumpMutableLiveData.postValue(result);
    }

    @Override
    public void onFailureFromRemoteDatabase(String message) {
        Result.Error result = new Result.Error(message);
        dumpMutableLiveData.postValue(result);
    }

    @Override
    public MutableLiveData<Result> getDump() {
        retrieveDumpData();
        return dumpMutableLiveData;
    }

    @Override
    public void retrieveDumpData() {
        baseDumpDataRemoteDataSource.getDump();
    }
}
