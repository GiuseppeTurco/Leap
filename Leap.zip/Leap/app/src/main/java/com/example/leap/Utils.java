package com.example.leap;

import static androidx.core.app.ActivityCompat.startActivityForResult;

import android.content.Intent;

public class Utils {
    final int SELECT_PICTURE = 200;

}
