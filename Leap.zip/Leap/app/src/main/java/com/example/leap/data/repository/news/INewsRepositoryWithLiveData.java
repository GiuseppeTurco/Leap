package com.example.leap.data.repository.news;

import androidx.lifecycle.MutableLiveData;

import com.example.leap.model.News;
import com.example.leap.model.Result;

public interface INewsRepositoryWithLiveData {

    MutableLiveData<Result> fetchNews(String country, int page, long lastUpdate);

    void fetchNews(String country, int page);

    MutableLiveData<Result> getFavoriteNews(boolean firstLoading);

    void updateNews(News news);

    void deleteFavoriteNews();

}
