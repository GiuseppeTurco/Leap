package com.example.leap.ui.main;

import android.app.Application;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import com.example.leap.data.repository.item.IItemRepository;

public class BarcodeViewModelFactory implements ViewModelProvider.Factory {
    private final IItemRepository itemRepository;
    private Application application;

    public BarcodeViewModelFactory(IItemRepository itemRepository, Application application) {
        this.itemRepository = itemRepository;
        this.application = application;
    }

    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        return (T) new BarcodeViewModel(itemRepository, application);
    }
}