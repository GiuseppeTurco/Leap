package com.example.leap.util;

import android.app.Application;

import com.example.leap.R;

public class ErrorMessagesUtil {
    private Application application;

    public ErrorMessagesUtil(Application application) {
        this.application = application;
    }
    public String getErrorMessage(String errorType) {
        switch(errorType) {
            default:
                return application.getString(R.string.unexpected_error);
    }
    }
}
