package com.example.leap.util;

import static com.example.leap.util.Constants.API_KEY_ERROR;
import static com.example.leap.util.Constants.RETROFIT_ERROR;

import android.app.Application;

import com.example.leap.R;


public class ErrorMessagesUtil {

    private Application application;

    public ErrorMessagesUtil(Application application) {
        this.application = application;
    }

    public String getErrorMessage(String errorType) {
        switch(errorType) {
            case RETROFIT_ERROR:
                return application.getString(R.string.error_retrieving_news);
            case API_KEY_ERROR:
                return application.getString(R.string.api_key_error);
            default:
                return application.getString(R.string.unexpected_error);
        }
    }
}
