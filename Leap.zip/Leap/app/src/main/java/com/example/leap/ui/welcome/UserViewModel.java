package com.example.leap.ui.welcome;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.Set;

import com.example.leap.data.repository.user.IUserRepository;
import com.example.leap.model.Result;
import com.example.leap.model.User;

public class UserViewModel extends ViewModel {
    private static final String TAG = UserViewModel.class.getSimpleName();

    private final IUserRepository userRepository;
    private MutableLiveData<Result> userMutableLiveData;
    private boolean authenticationError;

    public UserViewModel(IUserRepository userRepository) {
        this.userRepository = userRepository;
        authenticationError = false;
    }

    public MutableLiveData<Result> getUserMutableLiveData(
            String email, String password, boolean isUserRegistered) {
        if (userMutableLiveData == null) {
            getUserData(email, password, isUserRegistered);
        }
        return userMutableLiveData;
    }

    public MutableLiveData<Result> getUserMutableLiveData(
            String name, String surname, String email,
            String password, String comune, boolean isUserRegistered) {
        if (userMutableLiveData == null) {
            getUserData(name, surname, email, password, comune, isUserRegistered);
        }
        return userMutableLiveData;
    }

    public MutableLiveData<Result> getUserMutableLiveData(String token) {
        if (userMutableLiveData == null) {
            getUserData(token);
        }
        return userMutableLiveData;
    }

    public MutableLiveData<Result> getGoogleUserMutableLiveData(String token) {
        if (userMutableLiveData == null) {
            getUserData(token);
        }
        return userMutableLiveData;
    }

    public User getLoggedUser() {
        return userRepository.getLoggedUser();
    }

    public MutableLiveData<Result> logout() {
        if (userMutableLiveData == null) {
            userMutableLiveData = userRepository.logout();
        } else {
            userRepository.logout();
        }

        return userMutableLiveData;
    }

    public void getUser(String email, String password, boolean isUserRegistered) {
        userRepository.getUser("null", "null", email, password, "null", isUserRegistered);
    }

    public void getUser(String name, String surname, String email, String password, String comune, boolean isUserRegistered) {
        userRepository.getUser(name, surname, email, password, comune, isUserRegistered);
    }

    public boolean isAuthenticationError() {
        return authenticationError;
    }

    public void setAuthenticationError(boolean authenticationError) {
        this.authenticationError = authenticationError;
    }

    private void getUserData(String idToken) {
        userMutableLiveData = userRepository.getUser(idToken);
    }

    private void getUserData(String email, String password, boolean isUserRegistered) {
        userMutableLiveData = userRepository.getUser("null", "null", email, password, "null", isUserRegistered);
    }

    private void getUserData(String name, String surname, String email, String password, String comune, boolean isUserRegistered) {
        userMutableLiveData = userRepository.getUser(name, surname, email, password, comune, isUserRegistered);
    }
}
