package com.example.leap.data.source.item;

import com.example.leap.model.Item;

public abstract class BaseItemDataRemoteDataSource {
    protected ItemCallback itemCallback;


    public abstract Item getItem(Long ean);

    public void setItemResponseCallback(ItemCallback itemCallback) {
        this.itemCallback = itemCallback;
    }
}
