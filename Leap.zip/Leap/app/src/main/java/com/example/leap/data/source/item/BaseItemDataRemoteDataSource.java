package com.example.leap.data.source.item;

import com.example.leap.data.repository.dump.DumpResponseCallback;
import com.example.leap.data.repository.item.ItemRepository;
import com.example.leap.data.repository.item.ItemResponseCallback;
import com.example.leap.model.Dump;
import com.example.leap.model.Item;

import java.util.ArrayList;

public abstract class BaseItemDataRemoteDataSource {
    protected ItemCallback itemCallback;


    public abstract Item getItem(Long ean);

    public void setItemResponseCallback(ItemCallback itemCallback) {
        this.itemCallback = itemCallback;
    }
}
