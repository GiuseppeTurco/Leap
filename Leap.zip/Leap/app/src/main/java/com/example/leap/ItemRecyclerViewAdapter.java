package com.example.leap;

import android.app.Application;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.leap.model.Item;

import org.apache.commons.validator.routines.DomainValidator;

import java.util.List;

public class ItemRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    List<Item> itemList;
    private final Application application;

    Context context;



    public ItemRecyclerViewAdapter(@NonNull Context context, Application application, @NonNull List<Item> itemList) {

        this.application = application;
        this.itemList = itemList;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.one_item, parent, false);

        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((ItemViewHolder)holder).bind(itemList.get(position));
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder{
        TextView tvProductName;
        TextView tvBrand;
        TextView tvPackaging;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            tvBrand = itemView.findViewById(R.id.tv_brandone);
            tvPackaging = itemView.findViewById(R.id.tv_packagingone);
            tvProductName = itemView.findViewById(R.id.tv_productNameone);
        }
        public void bind(Item item) {
            tvBrand.setText(item.getBrand());
            tvPackaging.setText(item.getPackaging());
            tvProductName.setText(item.getProdName());
        }
    }

}
