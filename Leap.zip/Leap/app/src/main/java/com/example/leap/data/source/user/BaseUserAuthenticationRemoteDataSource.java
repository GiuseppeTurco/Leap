package com.example.leap.data.source.user;

import com.example.leap.data.repository.user.UserResponseCallback;
import com.example.leap.model.User;

/**
 * Base class to manage the user authentication.
 */
public abstract class BaseUserAuthenticationRemoteDataSource {
    protected UserResponseCallback userResponseCallback;

    public void setUserResponseCallback(UserResponseCallback userResponseCallback) {
        this.userResponseCallback = userResponseCallback;
    }
    public abstract User getLoggedUser();
    public abstract void logout();
    public abstract void signUp(String name, String surname, String email, String password, String comune);
    public abstract void signIn(String email, String password);
    public abstract void signInWithGoogle(String idToken);
}
