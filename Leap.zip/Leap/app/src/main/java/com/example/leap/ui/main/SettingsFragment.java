package com.example.leap.ui.main;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.example.leap.data.service.MyFirebaseMessagingService;
import com.example.leap.R;

import java.util.Locale;

public class SettingsFragment extends Fragment implements View.OnClickListener{

    private Context thiscontext;
    Switch aswitch;
    MyFirebaseMessagingService myFirebaseMessagingService;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        assert container != null;
        thiscontext = container.getContext();
        return inflater.inflate(R.layout.fragment_settings, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView contact_us_textView = view.findViewById(R.id.contact_us_text);
        TextView about_us_textView = view.findViewById(R.id.about_us_text);
        TextView faq_textView = view.findViewById(R.id.faq_text);

        contact_us_textView.setOnClickListener(this);
        about_us_textView.setOnClickListener(this);
        faq_textView.setOnClickListener(this);

        aswitch = getActivity().findViewById(R.id.switchNotifications);

        if(MainActivity.preferences.getBoolean("activateNotifications",false)){
            aswitch.setChecked(true);
            if(Locale.getDefault().getLanguage().equals("it"))
                aswitch.setText("Disattiva le Notifiche");
        }

        aswitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    if(Locale.getDefault().getLanguage().equals("it"))
                        aswitch.setText("Disattiva le Notifiche");
                }else{
                    //no notification get started
                    if(Locale.getDefault().getLanguage().equals("it"))
                        aswitch.setText("Attiva le Notifiche");
                }
                SharedPreferences.Editor editor = MainActivity.preferences.edit();
                editor.putBoolean("activateNotifications",isChecked);
                editor.commit();
            }
        });






    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.faq_text){
            Navigation.findNavController(v).navigate(R.id.action_settingsFragment_to_FAQFragment);
        }else if (v.getId() == R.id.about_us_text){
            Navigation.findNavController(v).navigate(R.id.action_settingsFragment_to_aboutUsFragment);
        }else if (v.getId() == R.id.contact_us_text){
            Navigation.findNavController(v).navigate(R.id.action_settingsFragment_to_contactFragment);
        }
    }



}