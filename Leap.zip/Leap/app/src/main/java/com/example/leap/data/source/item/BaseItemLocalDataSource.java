package com.example.leap.data.source.item;

import android.media.browse.MediaBrowser;

import com.example.leap.model.Item;

import java.util.List;

public abstract class BaseItemLocalDataSource {

    protected ItemCallback itemCallback;

    public void setItemCallback(ItemCallback itemCallback) {
        this.itemCallback = itemCallback;
    }

    public abstract void getItems();
    public abstract void insertItems(List<Item> newsList);
    public abstract void deleteAll();

    public abstract void insertItem(Item item);
}