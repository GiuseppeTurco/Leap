package com.example.leap.data.repository.item;

import androidx.lifecycle.MutableLiveData;

import com.example.leap.model.Item;
import com.example.leap.model.Result;

public interface IItemRepository {
    MutableLiveData<Result> getItem(Long ean);
    void retrieveItemData(Long ean);

    MutableLiveData<Result> insertItem(Item item);

    MutableLiveData<Result> getItems();
}
