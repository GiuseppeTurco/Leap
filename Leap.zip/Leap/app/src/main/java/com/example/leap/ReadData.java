package com.example.leap;

import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ReadData extends  BarcodeActivity{
    DatabaseReference reference;

    public void data() {

        TextView textView = findViewById(R.id.tvISBNres);
        String ISBNres = textView.getText().toString();
        if(!ISBNres.isEmpty()){
            readData(ISBNres);
        }
        else {
            toastie("please enter a isbn");
        }
    }

    private void readData(String ISBNres) {

        reference = FirebaseDatabase.getInstance().getReference("Products");
        reference.child(ISBNres).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {

                if(task.isSuccessful()){
                    if(task.getResult().exists()){
                        toastie("success");
                        DataSnapshot dataSnapshot = task.getResult();
                        String brand = String.valueOf(dataSnapshot.child("Brand"));
                        String product = String.valueOf(dataSnapshot.child("Product"));
                        String packaging = String.valueOf(dataSnapshot.child("Packaging"));
                        TextView tvBrand = findViewById(R.id.tvBrand);
                        tvBrand.setText(brand);
                        TextView tvProduct = findViewById(R.id.tvItem);
                        tvProduct.setText(product);
                        TextView tvPackaging = findViewById(R.id.tvPackging);
                        tvPackaging.setText(packaging);

                    }else{
                        toastie("isbn doesn't exist");
                    }

                }else{
                    toastie("failed to read");
                }

            }
        });
    }
}
