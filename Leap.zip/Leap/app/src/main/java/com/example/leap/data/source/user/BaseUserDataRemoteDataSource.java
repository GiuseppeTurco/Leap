package com.example.leap.data.source.user;

import java.util.Set;

import com.example.leap.data.repository.user.UserResponseCallback;
import com.example.leap.model.User;

/**
 * Base class to get the user data from a remote source.
 */
public abstract class BaseUserDataRemoteDataSource {
    protected UserResponseCallback userResponseCallback;

    public void setUserResponseCallback(UserResponseCallback userResponseCallback) {
        this.userResponseCallback = userResponseCallback;
    }

    public abstract User getUserdata(String idToken);
}
