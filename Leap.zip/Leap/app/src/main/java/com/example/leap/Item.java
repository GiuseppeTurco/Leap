package com.example.leap;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "Item")
public class Item {

    @ColumnInfo(name = "Item_ean")
    @PrimaryKey(autoGenerate = false)
    @NonNull
    String ean;

    @ColumnInfo(name= "prodName")
    String prodName;

    @ColumnInfo(name= "brand")
    String brand;

    @ColumnInfo(name= "packaging")
    String packaging;

    @Ignore
    public Item() {
    }



    public Item(String ean, String prodName, String brand, String packaging) {
        this.prodName = prodName;
        this.brand = brand;
        this.packaging = packaging;
        this.ean = ean;
    }

    @Override
    public String toString() {
        return "Item{" +
                "ean=" + ean +
                ", prodName='" + prodName + '\'' +
                ", brand='" + brand + '\'' +
                ", packaging='" + packaging + '\'' +
                '}';
    }

    public String getEan() {
        return ean;
    }

    public void setEan(String ean) {
        this.ean = ean;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPackaging() {
        return packaging;
    }

    public void setPackaging(String packaging) {
        this.packaging = packaging;
    }
}
