package com.example.leap.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Class that represents the result of an action that requires
 * the use of a Web Service or a local database.
 */
public abstract class Result {
    private Result() {}

    public boolean isSuccess() {
        if(this instanceof UserResponseSuccess || this instanceof DumpResponseSuccess || this instanceof ItemResponseSuccess){
            return true;
        } else {
            return false;
        }
    }

    /**
     * Class that represents a successful action during the interaction
     * with a Web Service or a local database.
     */
    public static final class UserResponseSuccess extends Result {
        private final User user;
        public UserResponseSuccess(User user) {
            this.user = user;
        }
        public User getData() {
            return user;
        }
    }

    public static final class DumpResponseSuccess extends Result {
        private final ArrayList<Dump> dump;
        public DumpResponseSuccess(ArrayList<Dump> dump) {
            this.dump = dump;
        }
        public ArrayList<Dump> getData() {return dump;}
    }
    public static final class ItemResponseSuccess extends Result {

        private final Item item;
        private final List<Item> itemList;

        public ItemResponseSuccess(Item item) {
            this.item = item;
            this.itemList = null;
        }

        public ItemResponseSuccess(List<Item> itemList){
            this.itemList = itemList;
            this.item = null;
        }

        public Item getData() {return item;}

        public List<Item> getDataList(){
            return itemList;
        }
    }

    public static final class NewsResponseSuccess extends Result {
        private final ItemResponse itemResponse;
        public NewsResponseSuccess(ItemResponse itemResponse) {
            this.itemResponse = itemResponse;
        }
        public ItemResponse getData() {
            return itemResponse;
        }
    }

    /**
     * Class that represents an error occurred during the interaction
     * with a Web Service or a local database.
     */
    public static final class Error extends Result {
        private final String message;
        public Error(String message) {
            this.message = message;
        }
        public String getMessage() {
            return message;
        }
    }
}
