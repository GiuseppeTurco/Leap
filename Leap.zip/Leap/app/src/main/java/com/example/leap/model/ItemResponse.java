package com.example.leap.model;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ItemResponse implements Parcelable {





    @SerializedName("articles")
    private List<Item> itemList;
    private Item item;


    public ItemResponse() {
    }

    public void setItemList(List<Item> newsList) {
        this.itemList = newsList;
        this.item = item;
    }



    protected ItemResponse(Parcel in) {
    }

    public static final Creator<ItemResponse> CREATOR = new Creator<ItemResponse>() {
        @Override
        public ItemResponse createFromParcel(Parcel in) {
            return new ItemResponse(in);
        }

        @Override
        public ItemResponse[] newArray(int size) {
            return new ItemResponse[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
    }

    public List<Item> getItemList() {
        return itemList;
    }
    
    public Item getItem(){
        return item;
    }
}
