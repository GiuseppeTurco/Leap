package com.example.leap.ui.main;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import com.example.leap.R;
import com.example.leap.data.repository.dump.IDumpRepository;
import com.example.leap.model.Dump;
import com.example.leap.model.Result;
import com.example.leap.util.ServiceLocator;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.snackbar.Snackbar;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class  MapsFragment extends Fragment {

    private SearchView mapSearchView;
    private GoogleMap gmap;
    private Context thiscontext;
    private DumpViewModel dumpViewModel;
    private ArrayList<Dump> dumpArrayList;

    private OnMapReadyCallback callback = new OnMapReadyCallback() {
        @Override
        public void onMapReady(GoogleMap googleMap) {
            gmap = googleMap;
            LatLng latLng = new LatLng(41.87194, 12.56738);
            gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 5));
            getDumps();
            gmap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(@NonNull Marker marker) {
                    int index = 0;
                    for(int i=0;i<dumpArrayList.size();i++){
                        if(marker.getTitle().equals(dumpArrayList.get(i).getName())){
                            index = i;
                            break;
                        }
                    }
                    DumpFragment dumpFragment = new DumpFragment(dumpArrayList.get(index));
                    getActivity().getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fl_wrapper, dumpFragment)
                            .commit();
                    return false;
                }
            });
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        thiscontext = container.getContext();
        return inflater.inflate(R.layout.fragment_maps, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dumpArrayList = new ArrayList<Dump>();

        IDumpRepository dumpRepository = ServiceLocator.getInstance().
                getDumpRepository(requireActivity().getApplication());
        dumpViewModel = new ViewModelProvider(
                requireActivity(),
                new DumpViewModelFactory(dumpRepository)).get(DumpViewModel.class);

        mapSearchView = view.findViewById(R.id.mapSearch);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);

        mapSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {

                String location = mapSearchView.getQuery().toString();
                List<Address> addressList = null;

                if (location != null) {
                    Geocoder geocoder = new Geocoder(thiscontext, Locale.getDefault());

                    try {
                        addressList = geocoder.getFromLocationName(location, 1);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    Address address = addressList.get(0);
                    LatLng latLng = new LatLng(address.getLatitude(), address.getLongitude());
                    gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
                }

                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                return false;
            }
        });

        if (mapFragment != null) {
            mapFragment.getMapAsync(callback);
        }
    }

    private void getDumps(){
        dumpViewModel.getDumpMutableLiveData().observe(
                getViewLifecycleOwner(), result -> {
                    if (result.isSuccess()) {
                        dumpArrayList = ((Result.DumpResponseSuccess) result).getData();
                        setMarkers();
                    } else {
                        Snackbar.make(requireActivity().findViewById(android.R.id.content),
                                "Error", Snackbar.LENGTH_SHORT).show();
                    }
                });
    }

    private void setMarkers(){
        float lat = 0;
        float lng = 0;
        for(int i=0;i<dumpArrayList.size();i++){
            lat = dumpArrayList.get(i).getLatitude();
            lng = dumpArrayList.get(i).getLongitude();

            gmap.addMarker(new MarkerOptions().position(new LatLng(lat, lng))
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                    .title(dumpArrayList.get(i).getName()));
        }
    }
}